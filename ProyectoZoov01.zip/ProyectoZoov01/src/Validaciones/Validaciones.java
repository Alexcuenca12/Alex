/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validaciones;

/**
 *
 * @author Usuario
 */
public class Validaciones {

    //Validacion del DNI
    public boolean validarDNI(String dni) {
        if (dni.length() == 10) {
            return true;
        }
        return false;
    }
// Validacion de Apellido del Personal

    public boolean validadApellido_Personal(String apellido) {
        if (apellido.trim().length() > 0 && apellido.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
// Validacion de Edad del Personal

    public boolean validadEdad_Personal(int edad) {
        if (edad > 18 && edad < 60) {
            return true;
        }
        return false;
    }
// Validacion de Edad del Animal

    public boolean validadEdad_Animal(int edadAnimal) {
        if (edadAnimal > 0 && edadAnimal < 100) {
            return true;
        }
        return false;
    }
//Validacion del Nombre del Personal

    public boolean validadNombre_Personal(String nombre) {
        if (nombre.trim().length() > 0 && nombre.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
//Validacion de la Direccion del Personal

    public boolean validadDireccion_Personal(String direccion) {
        if (direccion.trim().length() > 0 && direccion.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
//Validacion del Cargo del Personal

    public boolean validadCargo(String cargo) {
        if (cargo.trim().length() > 0 && cargo.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
//Validacion del AreaTrabajo del Personal

    public boolean validadArea_Trabajo(String areaTrabajo) {
        if (areaTrabajo.trim().length() > 0 && areaTrabajo.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
    //Validacion del Especialidad del Personal

    public boolean validadEspecialidad(String especialidadP) {
        if (especialidadP.trim().length() > 0 && especialidadP.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }
    //Validacion del ID

    public boolean validadID(String id) {
        if (id.length() < 10) {
            return true;
        }
        return false;
    }
//Validacion del ID

    public boolean validadFecha(String fecha) {
        if (fecha.trim().length() > 0 == true) {
            return true;
        }
        return false;
    }
//Validacion de la contraseña

    public boolean validadPasswoord(String password) {
        if (password.trim().length() > 8 && password.trim().toLowerCase().matches("([\\w&&[a-z]])*") == true) {
            return true;
        }
        return false;
    }

    //Validacion de Cantidades
    public boolean validadCantidad(Double cantidad) {
        if (cantidad > 0) {
            return true;
        }
        return false;
    }
}
