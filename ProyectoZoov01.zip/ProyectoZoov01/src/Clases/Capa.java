
package Clases;

import java.util.Vector;

public class Capa {
     //Clase vector
    private static Vector<Usuario> datos=new Vector<Usuario>();
    
    //Metodo para agregar datos de usuario
    public static void agregar(Usuario obj){
        datos.addElement(obj);
    }
    public static void eliminar(int pos){
        datos.removeElementAt(pos);
    }
    public static Vector mostrar(){
        return datos;
    }
}
