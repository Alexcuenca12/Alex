/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author The Prince
 */
public class DetalleDieta extends Dieta{
     private String cantPeso; 
     private String idProducto;
     private String Umedida;
     private String fecha;
     private String hora;

    public DetalleDieta() {
        super();
    }

    public DetalleDieta(String cantPeso, String idProducto, String Umedida, String fecha, String hora) {
        this.cantPeso = cantPeso;
        this.idProducto = idProducto;
        this.Umedida = Umedida;
        this.fecha = fecha;
        this.hora = hora;
    }

    public DetalleDieta( String idDieta, String idAnimal,String cantPeso, String idProducto, String Umedida, String fecha, String hora) {
        super(idDieta, idAnimal);
        this.cantPeso = cantPeso;
        this.idProducto = idProducto;
        this.Umedida = Umedida;
        this.fecha = fecha;
        this.hora = hora;
    }

    public String getCantPeso() {
        return cantPeso;
    }

    public void setCantPeso(String cantPeso) {
        this.cantPeso = cantPeso;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getUMedida() {
        return Umedida;
    }

    public void setUMedida(String Umedida) {
        this.Umedida = Umedida;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    @Override
    public String toString() {
        return super.toString()+ "cantPeso=" + cantPeso + ", idProducto=" + idProducto + ", Umedida=" + Umedida + ", fecha=" + fecha + ", hora=" + hora + '}';
    }

}