
package Interfaces;

import Clases.Veterinario;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class RegistroVeterinario extends javax.swing.JFrame {
   public static LinkedList<Veterinario> listaVeterinario = new LinkedList<Veterinario>();
    public int buscar;
    Veterinario vet=null;
    public RegistroVeterinario() {
        initComponents();
          this.setLocationRelativeTo(null);
    }

public String OpSex() {
        String op = null;
        if (RadioMasculinoV.isSelected()) {
            op = "Masculino";
        }
        if (RadioFemeninoV.isSelected()) {
            op = "Femenino";
        }
        return op;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        GroupSexo = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButtonConsultar = new javax.swing.JButton();
        txtAreaTrabajo = new javax.swing.JTextField();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        txtDNI = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtEspecialidad = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtCargo = new javax.swing.JTextField();
        txtConsultarV = new javax.swing.JTextField();
        jButtonSalir = new javax.swing.JButton();
        jButtonActualizar = new javax.swing.JButton();
        jButtonGuardar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jButtonEliminar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        SpinnerEdadVeterinario = new javax.swing.JSpinner();
        RadioMasculinoV = new javax.swing.JRadioButton();
        RadioFemeninoV = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 2, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REGISTRO VETERINARIO");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 80, -1, -1));

        jLabel2.setForeground(new java.awt.Color(153, 102, 0));
        jLabel2.setText("EDAD");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, -1, -1));

        jLabel3.setForeground(new java.awt.Color(153, 102, 0));
        jLabel3.setText("GENERO");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, -1, -1));

        jLabel4.setForeground(new java.awt.Color(153, 102, 0));
        jLabel4.setText("AREA TRABAJO");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, -1, -1));

        jLabel5.setForeground(new java.awt.Color(153, 102, 0));
        jLabel5.setText("APELLIDOS");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, -1, -1));

        jLabel6.setForeground(new java.awt.Color(153, 102, 0));
        jLabel6.setText("NOMBRES");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        jLabel7.setForeground(new java.awt.Color(153, 102, 0));
        jLabel7.setText("DNI");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, -1));

        jButtonConsultar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonConsultar.setText("CONSULTAR");
        jButtonConsultar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, -1, -1));
        jPanel1.add(txtAreaTrabajo, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, 190, -1));
        jPanel1.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 210, -1));
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 210, -1));
        jPanel1.add(txtDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 210, -1));

        jLabel9.setForeground(new java.awt.Color(153, 102, 0));
        jLabel9.setText("DIRECCION");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 170, -1, -1));
        jPanel1.add(txtEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 240, 190, -1));

        jLabel10.setForeground(new java.awt.Color(153, 102, 0));
        jLabel10.setText("ESPECIALIDAD");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 220, -1, -1));
        jPanel1.add(txtCargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 290, 190, -1));
        jPanel1.add(txtConsultarV, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 270, 30));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setBorderPainted(false);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, -1, -1));

        jButtonActualizar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, -1, -1));

        jButtonGuardar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 400, -1, -1));

        jLabel11.setForeground(new java.awt.Color(153, 102, 0));
        jLabel11.setText("CARGO");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 270, -1, -1));
        jPanel1.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, 190, -1));

        jButtonEliminar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonEliminar.setText("ELIMINAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/0015.jpg"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 110));
        jPanel1.add(SpinnerEdadVeterinario, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 60, -1));

        RadioMasculinoV.setBackground(new java.awt.Color(255, 255, 255));
        GroupSexo.add(RadioMasculinoV);
        RadioMasculinoV.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        RadioMasculinoV.setForeground(new java.awt.Color(153, 102, 0));
        RadioMasculinoV.setText("Masculino");
        RadioMasculinoV.setContentAreaFilled(false);
        RadioMasculinoV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioMasculinoVMouseClicked(evt);
            }
        });
        RadioMasculinoV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioMasculinoVActionPerformed(evt);
            }
        });
        jPanel1.add(RadioMasculinoV, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, -1, -1));

        RadioFemeninoV.setBackground(new java.awt.Color(255, 255, 255));
        GroupSexo.add(RadioFemeninoV);
        RadioFemeninoV.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        RadioFemeninoV.setForeground(new java.awt.Color(153, 102, 0));
        RadioFemeninoV.setText("Femenino");
        RadioFemeninoV.setContentAreaFilled(false);
        RadioFemeninoV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioFemeninoVMouseClicked(evt);
            }
        });
        jPanel1.add(RadioFemeninoV, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 140, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RadioMasculinoVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioMasculinoVMouseClicked

    }//GEN-LAST:event_RadioMasculinoVMouseClicked

    private void RadioMasculinoVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioMasculinoVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioMasculinoVActionPerformed

    private void RadioFemeninoVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioFemeninoVMouseClicked

    }//GEN-LAST:event_RadioFemeninoVMouseClicked

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
        Menu remenu2 = new Menu();
        remenu2.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
            System.out.println("Se ha presinado el Boton guardar");
        boolean resp=false;
        try {
            if (txtDNI.getText().equals("") || txtNombres.getText().equals("") || txtApellidos.getText().equals("") | txtDireccion.getText().equals("") || txtCargo.getText().equals("") || txtAreaTrabajo.getText().equals("")|| txtEspecialidad.getText().equals("")|| SpinnerEdadVeterinario.getValue().equals(0)|| GroupSexo.isSelected(null) ) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String DniV = txtDNI.getText();
                String nomV=txtNombres.getText();
                String apeV=txtApellidos.getText();
                String direcc = txtDireccion.getText();
                String cargo=txtCargo.getText();
                String areaT=txtAreaTrabajo.getText();
                String espe= txtEspecialidad.getText();
                String sexo= OpSex();
                int  EdadS = Integer.parseInt(SpinnerEdadVeterinario.getValue().toString());
//
                for (int i = 0; i < RegistroVeterinario.listaVeterinario.size(); i++) {
                    Veterinario vet;
                    vet = (Veterinario) RegistroVeterinario.listaVeterinario.get(i);
                    if (DniV.equalsIgnoreCase(vet.getDNI())) {
                         JOptionPane.showMessageDialog(null, "El DNI del veterinario ya se encuentra registrado");
                    } else {
                       resp=true;
                    }
                }
                    if(resp=true){
                    Veterinario vet = new Veterinario(DniV, nomV, apeV, EdadS, sexo, direcc, espe,cargo,areaT);
                    listaVeterinario.add(vet);
                    System.out.println(vet);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    }
            }                
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatosV();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
            int res = JOptionPane.showConfirmDialog(RegistroVeterinario.this, "Esta seguro de Modificar los datos \nde este Veterinario", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String DniV = txtDNI.getText();
                String nomV=txtNombres.getText();
                String apeV=txtApellidos.getText();
                String direcc = txtDireccion.getText();
                String cargo=txtCargo.getText();
                String areaT=txtAreaTrabajo.getText();
                String espe= txtEspecialidad.getText();
                String sexo= OpSex();
                int  EdadS = Integer.parseInt(SpinnerEdadVeterinario.getValue().toString());

                Veterinario vet = new Veterinario(DniV, nomV, apeV, EdadS, sexo, direcc, espe,cargo,areaT);
                RegistroVeterinario.listaVeterinario.set(buscar, vet);
                JOptionPane.showMessageDialog(null, "Datos del Veterinario Actualizados");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatosV();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
         Integer EdadS;
        String edad;
        try {
        String consultar = txtConsultarV.getText().trim();
        boolean encontrar = false;
       
            for (int i = 0; i <listaVeterinario.size(); i++) {
                if (listaVeterinario.get(i).getDNI().equalsIgnoreCase(consultar)) {
                  vet=listaVeterinario.get(i);
                  encontrar=true;
                }
                if (encontrar == true) {
                    txtDNI.setText(vet.getDNI());
                    txtDNI.setEnabled(false);
                    txtNombres.setText(vet.getNombre());
                    txtApellidos.setText(vet.getApellidos());
                    txtDireccion.setText(vet.getDireccion());
                    txtCargo.setText(vet.getCargo());
                    txtAreaTrabajo.setText(vet.getAreaTrabajo());
                    txtEspecialidad.setText(vet.getEspecialidad());
                    SpinnerEdadVeterinario.setValue(vet.getEdad());
                    String radioVet = (vet.getGenero());
                    if ("Masculino".equals(radioVet)) {
                        RadioMasculinoV.setSelected(true);
                    } else if ("Femenino" == (radioVet)) {
                        RadioFemeninoV.setSelected(true);
                    }
                    buscar = i;
                    JOptionPane.showMessageDialog(null, "Se ha encontrado al veterinario");
                }
            }
                if(!encontrar){
                    JOptionPane.showMessageDialog(null, "No Se ha podido encontrar al veterinario"); 
                
                }
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultarV.setText("");
    
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
         int res = JOptionPane.showConfirmDialog(RegistroVeterinario.this, "Esta seguro de eliminar este Veterinario", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroVeterinario.listaVeterinario.remove(buscar);
                   LimpiarDatosV();

                JOptionPane.showMessageDialog(null, "Veterinario Eliminado");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
                                     
    }//GEN-LAST:event_jButtonEliminarActionPerformed
    public void LimpiarDatosV(){
        txtDNI.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtDireccion.setText("");
        txtCargo.setText("");  
        txtAreaTrabajo.setText("");
        txtEspecialidad.setText("");
        SpinnerEdadVeterinario.setValue(0);
        GroupSexo.clearSelection();
        txtDNI.setEnabled(true);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroVeterinario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroVeterinario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroVeterinario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroVeterinario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroVeterinario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup GroupSexo;
    public static javax.swing.JRadioButton RadioFemeninoV;
    public static javax.swing.JRadioButton RadioMasculinoV;
    public static javax.swing.JSpinner SpinnerEdadVeterinario;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JTextField txtApellidos;
    public static javax.swing.JTextField txtAreaTrabajo;
    public static javax.swing.JTextField txtCargo;
    public static javax.swing.JTextField txtConsultarV;
    public static javax.swing.JTextField txtDNI;
    public static javax.swing.JTextField txtDireccion;
    public static javax.swing.JTextField txtEspecialidad;
    public static javax.swing.JTextField txtNombres;
    // End of variables declaration//GEN-END:variables
}
