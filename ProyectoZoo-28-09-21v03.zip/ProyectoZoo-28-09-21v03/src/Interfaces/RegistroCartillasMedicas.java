
package Interfaces;

import Clases.CartillaMedica;
import Ventanas.ConsultarIdAnimalCartilla;
import Ventanas.ConsultarIdVeterinarioCartilla;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class RegistroCartillasMedicas extends javax.swing.JFrame {
 public static LinkedList<CartillaMedica> listaCartilla = new LinkedList<CartillaMedica>();
    public int buscar;
    CartillaMedica cart=null;
      SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    public RegistroCartillasMedicas() {
        initComponents();
        this.setLocationRelativeTo(null);
        txtIdAnimalC.setEnabled(false);
        txtNombreC.setEnabled(false);
        txtNombreV.setEnabled(false);
        txtIdDniVeterinarioC.setEnabled(false);
        txtNombreVetC.setEnabled(false);
        txtApellidoVetC.setEnabled(false);
        txtFechaCuracion.setVisible(false);
        txtFechaDiagnostico.setVisible(false);
        txtIdReceta.setEnabled(false);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButtonCosultar = new javax.swing.JButton();
        txtNombreEnfermedad = new javax.swing.JTextField();
        txtIdReceta = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtConsultar = new javax.swing.JTextField();
        jButtonActualizar = new javax.swing.JButton();
        jButtonGuardar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtIdAnimalC = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtIdCartilla = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtIdDniVeterinarioC = new javax.swing.JTextField();
        jButtonEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObservacion = new javax.swing.JTextArea();
        jLabel14 = new javax.swing.JLabel();
        DateFechaCuracion = new com.toedter.calendar.JDateChooser();
        DateFechaDiagnostico = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtNombreV = new javax.swing.JTextField();
        txtNombreC = new javax.swing.JTextField();
        txtNombreVetC = new javax.swing.JTextField();
        txtApellidoVetC = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        BConsultarIdReceta = new javax.swing.JButton();
        BConsultarDniVeterinario = new javax.swing.JButton();
        txtFechaCuracion = new javax.swing.JTextField();
        txtFechaDiagnostico = new javax.swing.JTextField();
        BConsultarIdAnimal = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuOpciones = new javax.swing.JMenu();
        jMenuItemRegistraReceta = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("REGISTRO CARTILLA MEDICA");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("NOMBRE ENFERMEDAD");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("ID RECETA");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        jButtonCosultar.setText("CONSULTAR");
        jButtonCosultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCosultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCosultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, -1, -1));
        jPanel1.add(txtNombreEnfermedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 230, -1));
        jPanel1.add(txtIdReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 230, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setText("ID ANIMAL");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, -1, -1));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel10.setText("FECHA  CURACIÓN");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, -1, -1));
        jPanel1.add(txtConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 270, 20));

        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 410, -1, -1));

        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 410, -1, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel11.setText("OBSERVACIONES");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 240, -1, -1));
        jPanel1.add(txtIdAnimalC, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 210, 140, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel12.setText("ID CARTILLA MEDICA");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));
        jPanel1.add(txtIdCartilla, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 230, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel13.setText("APELLIDO");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 140, -1, -1));
        jPanel1.add(txtIdDniVeterinarioC, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, 140, -1));

        jButtonEliminar.setText("ELIMINAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 410, -1, -1));

        txtObservacion.setColumns(20);
        txtObservacion.setRows(5);
        jScrollPane1.setViewportView(txtObservacion);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 270, 180, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel14.setText("FECHA  DIAGNOSTICO");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));
        jPanel1.add(DateFechaCuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 110, -1));
        jPanel1.add(DateFechaDiagnostico, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 120, -1));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel15.setText("DNI VETERINARIO");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, -1, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel16.setText("NOMBRE VULGAR");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 190, -1, -1));
        jPanel1.add(txtNombreV, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 210, 120, -1));
        jPanel1.add(txtNombreC, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 210, 120, 20));
        jPanel1.add(txtNombreVetC, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 160, 120, -1));
        jPanel1.add(txtApellidoVetC, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 160, 120, -1));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel17.setText("NOMBRE ");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 140, -1, -1));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel18.setText("NOMBRE CIENTIFICO");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 190, -1, -1));

        BConsultarIdReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdReceta.setBorderPainted(false);
        BConsultarIdReceta.setContentAreaFilled(false);
        BConsultarIdReceta.setDefaultCapable(false);
        BConsultarIdReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdRecetaActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 30, 40));

        BConsultarDniVeterinario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarDniVeterinario.setBorderPainted(false);
        BConsultarDniVeterinario.setContentAreaFilled(false);
        BConsultarDniVeterinario.setDefaultCapable(false);
        BConsultarDniVeterinario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarDniVeterinarioActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarDniVeterinario, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, 30, 40));
        jPanel1.add(txtFechaCuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 100, -1));
        jPanel1.add(txtFechaDiagnostico, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 310, 100, -1));

        BConsultarIdAnimal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdAnimal.setBorderPainted(false);
        BConsultarIdAnimal.setContentAreaFilled(false);
        BConsultarIdAnimal.setDefaultCapable(false);
        BConsultarIdAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdAnimalActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, 30, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/0027.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 450));

        jMenuOpciones.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jMenuOpciones.setForeground(new java.awt.Color(153, 51, 0));
        jMenuOpciones.setText("OPCIONES");

        jMenuItemRegistraReceta.setText("REGISTRAR RECETA");
        jMenuOpciones.add(jMenuItemRegistraReceta);

        jMenuItemSalir.setText("SALIR");
        jMenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSalirActionPerformed(evt);
            }
        });
        jMenuOpciones.add(jMenuItemSalir);

        jMenuBar1.add(jMenuOpciones);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BConsultarIdRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdRecetaActionPerformed
        System.out.println("Ha presionado buscar id receta");
//        ConsultaIdAnimal verveid=new ConsultaIdAnimal();
//        verveid.setVisible(true);
    }//GEN-LAST:event_BConsultarIdRecetaActionPerformed

    private void BConsultarDniVeterinarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarDniVeterinarioActionPerformed
        System.out.println("Ha presionado buscar id veterinario");
        ConsultarIdVeterinarioCartilla verveidV=new ConsultarIdVeterinarioCartilla();
        verveidV.setVisible(true);
    }//GEN-LAST:event_BConsultarDniVeterinarioActionPerformed

    private void BConsultarIdAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdAnimalActionPerformed
        System.out.println("Ha presionado buscar id animal");
        ConsultarIdAnimalCartilla verveidAC=new ConsultarIdAnimalCartilla();
        verveidAC.setVisible(true);
    }//GEN-LAST:event_BConsultarIdAnimalActionPerformed

    private void jMenuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSalirActionPerformed
         Menu remenu2 = new Menu();
        remenu2.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jMenuItemSalirActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
            System.out.println("Se ha presinado el Boton guardar");
        boolean resp=false;
        try {
            if (txtIdCartilla.getText().equals("") || txtIdDniVeterinarioC.getText().equals("") || txtIdReceta.getText().equals("") | txtIdAnimalC.getText().equals("") || txtNombreEnfermedad.getText().equals("") || txtObservacion.getText().equals("")|| DateFechaDiagnostico.getDate().equals("")|| DateFechaCuracion.getDate().equals("") ) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String idC = txtIdCartilla.getText();
                String nomEnfermedad=txtNombreEnfermedad.getText();
                String DniVet=txtIdDniVeterinarioC.getText();
                String idAni = txtIdAnimalC.getText();
                String idReceta = txtIdReceta.getText();
                String obser = txtObservacion.getText();
                String fechaDiagn = formato.format(DateFechaDiagnostico.getDate());
                String fechaCuracion = formato.format(DateFechaCuracion.getDate());
             
                    CartillaMedica cart = new CartillaMedica(idC, DniVet, idReceta, idAni, nomEnfermedad, fechaDiagn, fechaCuracion,obser);
                    listaCartilla.add(cart);
                    System.out.println(cart);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    
            }                
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatosCM();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
           int res = JOptionPane.showConfirmDialog(RegistroCartillasMedicas.this, "Esta seguro de Modificar los datos \nde esta Cartilla Medica", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String idC = txtIdCartilla.getText();
                String nomEnfermedad=txtNombreEnfermedad.getText();
                String DniVet=txtIdDniVeterinarioC.getText();
                String idAni = txtIdAnimalC.getText();
                String idReceta = txtIdReceta.getText();
                String obser = txtObservacion.getText();
                String fechaDiagn = formato.format(DateFechaDiagnostico.getDate());
                String fechaCuracion = formato.format(DateFechaCuracion.getDate());

                CartillaMedica cart = new CartillaMedica(idC, DniVet, idReceta, idAni, nomEnfermedad, fechaDiagn, fechaCuracion,obser);
                RegistroCartillasMedicas.listaCartilla.set(buscar, cart);
                JOptionPane.showMessageDialog(null, "Datos de la Cartilla Medica Actualizados");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatosCM();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
             int res = JOptionPane.showConfirmDialog(RegistroCartillasMedicas.this, "Esta seguro de eliminar esta CartillaMedica", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroCartillasMedicas.listaCartilla.remove(buscar);
                   LimpiarDatosCM();

                JOptionPane.showMessageDialog(null, "Cartilla Medica Eliminado");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jButtonCosultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCosultarActionPerformed
        txtFechaCuracion.setVisible(true);
        txtFechaDiagnostico.setVisible(true);
           try {
        String consultar = txtConsultar.getText().trim();
        boolean encontrar = false;
       
            for (int i = 0; i <listaCartilla.size(); i++) {
                if (listaCartilla.get(i).getIdCartilla().equalsIgnoreCase(consultar)) {
                  cart=listaCartilla.get(i);
                  encontrar=true;
                }
                if (encontrar == true) {
                    txtIdCartilla.setText(cart.getIdCartilla());
                    txtIdDniVeterinarioC.setText(cart.getDniVeterinario());
                    txtIdReceta.setText(cart.getIdReceta());
                    txtIdAnimalC.setText(cart.getIdAnimal());
                    txtNombreEnfermedad.setText(cart.getNomEnfermedad());
                    txtObservacion.setText(cart.getObservaciones());
                    txtFechaCuracion.setText(cart.getFechaCuracion());
                    txtFechaDiagnostico.setText(cart.getFechaDiagnostico());
                    buscar = i;
                    JOptionPane.showMessageDialog(null, "Se ha encontrado la cartilla Medica");
                }
            }
                if(!encontrar){
                    JOptionPane.showMessageDialog(null, "No Se ha podido encontrar la cartilla medica"); 
                
                }
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultar.setText("");
    
    }//GEN-LAST:event_jButtonCosultarActionPerformed

    public void LimpiarDatosCM(){
        txtIdCartilla.setText("");
        txtIdAnimalC.setText("");
        txtNombreV.setText("");
        txtNombreC.setText("");
        txtIdDniVeterinarioC.setText("");
        txtNombreVetC.setText("");
        txtApellidoVetC.setText("");
        txtIdReceta.setText("");
        txtNombreEnfermedad.setText("");  
        txtObservacion.setText("");
        DateFechaCuracion.setCalendar(null);
        txtFechaCuracion.setText("");
        DateFechaDiagnostico.setCalendar(null);
        txtFechaDiagnostico.setText("");
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroCartillasMedicas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroCartillasMedicas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroCartillasMedicas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroCartillasMedicas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroCartillasMedicas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BConsultarDniVeterinario;
    private javax.swing.JButton BConsultarIdAnimal;
    private javax.swing.JButton BConsultarIdReceta;
    private com.toedter.calendar.JDateChooser DateFechaCuracion;
    private com.toedter.calendar.JDateChooser DateFechaDiagnostico;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonCosultar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemRegistraReceta;
    private javax.swing.JMenuItem jMenuItemSalir;
    private javax.swing.JMenu jMenuOpciones;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTextField txtApellidoVetC;
    private javax.swing.JTextField txtConsultar;
    private javax.swing.JTextField txtFechaCuracion;
    private javax.swing.JTextField txtFechaDiagnostico;
    public static javax.swing.JTextField txtIdAnimalC;
    private javax.swing.JTextField txtIdCartilla;
    public static javax.swing.JTextField txtIdDniVeterinarioC;
    private javax.swing.JTextField txtIdReceta;
    public static javax.swing.JTextField txtNombreC;
    private javax.swing.JTextField txtNombreEnfermedad;
    public static javax.swing.JTextField txtNombreV;
    public static javax.swing.JTextField txtNombreVetC;
    private javax.swing.JTextArea txtObservacion;
    // End of variables declaration//GEN-END:variables
}
