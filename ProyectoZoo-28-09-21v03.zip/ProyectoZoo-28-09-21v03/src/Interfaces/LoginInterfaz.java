package Interfaces;

import javax.swing.JOptionPane;
import Clases.Usuario;
import java.util.LinkedList;

public class LoginInterfaz extends javax.swing.JFrame {

    //LINKEDLIST
    public static LinkedList<Usuario> listausuario = new LinkedList<>();
    //variables
    String user;
    public static String password;
    boolean correcto = false;

    public LoginInterfaz() {
        initComponents();
        setLocationRelativeTo(null); //centrar la ventana
        for (int i = 0; i < RegistroUsuario.listausuarios.size(); i++) {
            listausuario.add(RegistroUsuario.listausuarios.get(i));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ButtonSalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        txtContraseña = new javax.swing.JPasswordField();
        contraseña = new javax.swing.JLabel();
        TxtUsuario = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ButtonIniciarS = new javax.swing.JButton();
        Icon = new javax.swing.JLabel();
        usuario = new javax.swing.JLabel();
        Fondo = new javax.swing.JLabel();
        btnRestablecerContraseña = new javax.swing.JButton();
        TipoUsuario = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(750, 422));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/salir.png"))); // NOI18N
        ButtonSalir.setBorder(null);
        ButtonSalir.setBorderPainted(false);
        ButtonSalir.setContentAreaFilled(false);
        ButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSalirActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtContraseña.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(txtContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 370, 190, 30));

        contraseña.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        contraseña.setForeground(new java.awt.Color(153, 102, 0));
        contraseña.setText("CONTRASEÑA:");
        jPanel1.add(contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 340, -1, 20));

        TxtUsuario.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(TxtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 370, 190, 30));

        jLabel1.setFont(new java.awt.Font("SimSun-ExtB", 1, 65)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("NIA");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 130, -1, -1));

        jLabel2.setFont(new java.awt.Font("SimSun-ExtB", 1, 65)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 102, 0));
        jLabel2.setText("ZOO");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 30, -1, -1));

        jLabel5.setFont(new java.awt.Font("SimSun-ExtB", 1, 65)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 102, 0));
        jLabel5.setText("NAR");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("SimSun-ExtB", 1, 65)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ZOOLOGICO");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 30, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/colorbi.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 340, 330));

        ButtonIniciarS.setBackground(new java.awt.Color(204, 102, 0));
        ButtonIniciarS.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        ButtonIniciarS.setText("INICIAR SESION");
        ButtonIniciarS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ButtonIniciarS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonIniciarSActionPerformed(evt);
            }
        });
        jPanel1.add(ButtonIniciarS, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 430, 120, 20));

        Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/login.png"))); // NOI18N
        jPanel1.add(Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, -1, 250));

        usuario.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        usuario.setForeground(new java.awt.Color(153, 102, 0));
        usuario.setText("USUARIO:");
        jPanel1.add(usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 330, -1, 20));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/unnamed.jpg"))); // NOI18N
        jPanel1.add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-830, 0, 1160, 500));

        btnRestablecerContraseña.setText("RESTABLECER CONTRASEÑA");
        btnRestablecerContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRestablecerContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(btnRestablecerContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 430, -1, 20));

        TipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "GERENTE", "VETERINARIO", "CUIDADOR", "GUARDIA" }));
        TipoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(TipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 290, 120, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 102, 0));
        jLabel6.setText("TIPO USUARIO:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    void ocultar() {
        if (TipoUsuario.getSelectedItem().equals("VETERINARIO")) {
            Menu acceso = new Menu();
            acceso.jMenuGestionAnimales.setVisible(false);
            acceso.jMenuGestionAlmacen.setVisible(false);
            acceso.jMenuGestionZoo.setVisible(false);
            acceso.jMenuGestionEmpleados.setVisible(false);
            acceso.jMenuProveedores.setVisible(false);
            acceso.show();
        } else {
            if (TipoUsuario.getSelectedItem().equals("GUARDIA")) {
                Menu acceso = new Menu();
                acceso.jMenuGestionAnimales.setVisible(false);
                acceso.jMenuGestionAlmacen.setVisible(false);
                acceso.jMenuGestionEmpleados.setVisible(false);
                acceso.jMenuProveedores.setVisible(false);
                acceso.jMenuCarnetVacuna.setVisible(false);
                acceso.jMenuCartillaMedica.setVisible(false);
                acceso.show();
            }else{
                if (TipoUsuario.getSelectedItem().equals("CUIDADOR")) {
                    Menu acceso = new Menu();
                    acceso.jMenuGestionAlmacen.setVisible(false);
                    acceso.jMenuGestionZoo.setVisible(false);
                    acceso.jMenuGestionEmpleados.setVisible(false);
                    acceso.jMenuProveedores.setVisible(false);
                    acceso.jMenuCarnetVacuna.setVisible(false);
                    acceso.jMenuCartillaMedica.setVisible(false);
                    acceso.show();
                }
            }
        }
    }
    private void ButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ButtonSalirActionPerformed

    private void ButtonIniciarSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonIniciarSActionPerformed
        String usuario = TxtUsuario.getText();
        String contraseña = txtContraseña.getText();
        String tipoUsuario = TipoUsuario.getSelectedItem().toString();
        int posicion = Usuario.verificarLogeo(usuario, contraseña, tipoUsuario);
        if (TipoUsuario.getSelectedItem().equals("GERENTE") && usuario.equals("Admin") && contraseña.equals("admin123")) {
            Menu acceso = new Menu();
            acceso.setVisible(true);
            this.setVisible(false);
            //Verificamos si los datos ingresados no coinciden con el metodo verificarLogeo de la clase Usuario
        } else if (Usuario.verificarLogeo(usuario, contraseña, tipoUsuario)==-1) {
           JOptionPane.showMessageDialog(null, "Usuario o Contraseña incorrectos");
        }else{
            //Si no ingresar al sistema y mostrar sus respectivas ventanas 
             Menu acceso = new Menu();
            acceso.setVisible(true);
            this.setVisible(false);
            ocultar();
        }
    }//GEN-LAST:event_ButtonIniciarSActionPerformed

    private void btnRestablecerContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRestablecerContraseñaActionPerformed
        RestablecerContraseña acceso = new RestablecerContraseña();
        acceso.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRestablecerContraseñaActionPerformed

    private void TipoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoUsuarioActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginInterfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginInterfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonIniciarS;
    private javax.swing.JButton ButtonSalir;
    private javax.swing.JLabel Fondo;
    private javax.swing.JLabel Icon;
    private javax.swing.JComboBox<String> TipoUsuario;
    private javax.swing.JTextField TxtUsuario;
    private javax.swing.JButton btnRestablecerContraseña;
    private javax.swing.JLabel contraseña;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txtContraseña;
    private javax.swing.JLabel usuario;
    // End of variables declaration//GEN-END:variables
}
