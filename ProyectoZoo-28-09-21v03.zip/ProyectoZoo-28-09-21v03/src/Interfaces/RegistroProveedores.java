
package Interfaces;

import Clases.Proveedor;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class RegistroProveedores extends javax.swing.JFrame {
  public static LinkedList<Proveedor> listaProv = new LinkedList<Proveedor>();
    public int buscar;
     Proveedor prov=null;
    public RegistroProveedores() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButtonConsultar = new javax.swing.JButton();
        txtNifProveedor = new javax.swing.JTextField();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtNombreEmpresa = new javax.swing.JTextField();
        txtConsultar = new javax.swing.JTextField();
        jButtonSalir = new javax.swing.JButton();
        jButtonActualizar = new javax.swing.JButton();
        jButtonGuardar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jButtonEliminar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JFormattedTextField();
        FONDOPROV = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REGISTRO PROVEEDORES");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 51, 0));
        jLabel5.setText("APELLIDOS");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 51, 0));
        jLabel6.setText("NOMBRES");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 51, 0));
        jLabel8.setText("NIF PROVEEDOR");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));

        jButtonConsultar.setForeground(new java.awt.Color(102, 51, 0));
        jButtonConsultar.setText("CONSULTAR");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, -1, -1));
        jPanel1.add(txtNifProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 210, -1));
        jPanel1.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 210, -1));
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 210, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 51, 0));
        jLabel9.setText("CORREO");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 140, -1, -1));

        txtNombreEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombreEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 190, -1));

        txtConsultar.setForeground(new java.awt.Color(102, 51, 0));
        jPanel1.add(txtConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, 270, 20));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        jButtonActualizar.setForeground(new java.awt.Color(102, 51, 0));
        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 390, -1, -1));

        jButtonGuardar.setForeground(new java.awt.Color(102, 51, 0));
        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, -1, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(102, 51, 0));
        jLabel11.setText("NOMBRE EMPRESA");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 250, -1, -1));
        jPanel1.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 160, 190, -1));

        jButtonEliminar.setForeground(new java.awt.Color(102, 51, 0));
        jButtonEliminar.setText("ELIMINAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 390, -1, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 51, 0));
        jLabel12.setText("TELEFONO");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 190, -1, -1));

        try {
            txtTelefono.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, 190, -1));

        FONDOPROV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/0025.jpg"))); // NOI18N
        jPanel1.add(FONDOPROV, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 0, 650, 440));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreEmpresaActionPerformed

    }//GEN-LAST:event_txtNombreEmpresaActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
              System.out.println("Se ha presinado el Boton guardar");
        boolean resp=false;
        try {
            if (txtNifProveedor.getText().equals("") || txtNombres.getText().equals("") || txtApellidos.getText().equals("") | txtCorreo.getText().equals("") || txtTelefono.getText().equals("") || txtNombreEmpresa.getText().equals("") ) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String NifP = txtNifProveedor.getText();
                String nomP=txtNombres.getText();
                String apeP=txtApellidos.getText();
                String correoP = txtCorreo.getText();
                String telefonoP=txtTelefono.getText();
                String nomEmpresa=txtNombreEmpresa.getText();
                for (int i = 0; i < RegistroProveedores.listaProv.size(); i++) {
                    Proveedor prov;
                    prov = (Proveedor) RegistroProveedores.listaProv.get(i);
                    if (NifP.equalsIgnoreCase(prov.getNifProveedor())) {
                         JOptionPane.showMessageDialog(null, "El NIF del Proveedor ya se encuentra registrado");
                    } else {
                       resp=true;
                    }
                }
                    if(resp=true){
                    Proveedor prov = new Proveedor(NifP,nomP,apeP,correoP,telefonoP,nomEmpresa);
                    listaProv.add(prov);
                    System.out.println(prov);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    }
            }                
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatosP();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
         int res = JOptionPane.showConfirmDialog(RegistroProveedores.this, "Esta seguro de Modificar los datos \nde este Proveedor", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String NifP = txtNifProveedor.getText();
                String nomP=txtNombres.getText();
                String apeP=txtApellidos.getText();
                String correoP = txtCorreo.getText();
                String telefonoP=txtTelefono.getText();
                String nomEmpresa=txtNombreEmpresa.getText();

                Proveedor prov = new Proveedor(NifP,nomP,apeP,correoP,telefonoP,nomEmpresa);
                RegistroProveedores.listaProv.set(buscar, prov);
                JOptionPane.showMessageDialog(null, "Datos del Proveedor Actualizados");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatosP();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
          int res = JOptionPane.showConfirmDialog(RegistroProveedores.this, "Esta seguro de eliminar este Proveedor", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroProveedores.listaProv.remove(buscar);
                   LimpiarDatosP();

                JOptionPane.showMessageDialog(null, "Proveedor Eliminado");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
        try {
        String consultar = txtConsultar.getText().trim();
        boolean encontrar = false;
       
            for (int i = 0; i <listaProv.size(); i++) {
                if (listaProv.get(i).getNifProveedor().equalsIgnoreCase(consultar)) {
                  prov=listaProv.get(i);
                  encontrar=true;
                }
                if (encontrar == true) {
                    txtNifProveedor.setText(prov.getNifProveedor());
                    txtNifProveedor.setEnabled(false);
                    txtNombres.setText(prov.getNombre());
                    txtApellidos.setText(prov.getApellido());
                    txtCorreo.setText(prov.getCorreo());
                    txtTelefono.setText(prov.getTelefono());
                    txtNombreEmpresa.setText(prov.getNombreEmpresa());
                    buscar = i;
                    JOptionPane.showMessageDialog(null, "Se ha encontrado al Proveedor");
                }
            }
                if(!encontrar){
                    JOptionPane.showMessageDialog(null, "No Se ha podido encontrar al Proveedor"); 
                
                }
            
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultar.setText("");
    
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
        Menu remenuP = new Menu();
        remenuP.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed
  public void LimpiarDatosP(){
        txtNifProveedor.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");  
        txtNombreEmpresa.setText("");
        txtNifProveedor.setEnabled(true);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroProveedores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel FONDOPROV;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JTextField txtApellidos;
    public static javax.swing.JTextField txtConsultar;
    public static javax.swing.JTextField txtCorreo;
    public static javax.swing.JTextField txtNifProveedor;
    public static javax.swing.JTextField txtNombreEmpresa;
    public static javax.swing.JTextField txtNombres;
    public static javax.swing.JFormattedTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
