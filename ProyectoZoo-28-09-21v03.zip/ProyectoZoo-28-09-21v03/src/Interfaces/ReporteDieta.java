
package Interfaces;

import Clases.AlimentacionAnimal;
import Clases.Animal;
import static Interfaces.RegistroDieta.*;
import javax.swing.table.DefaultTableModel;


public class ReporteDieta extends javax.swing.JFrame {
   private DefaultTableModel modelo;
    int contador = 0;

    public ReporteDieta() {
        initComponents();
        this.setLocationRelativeTo(null);
        CargarModelo();
        CargarDatos();
    }

 private void CargarModelo() { //establecemos un modelo de tabla
        try {
            String datos[][] = {};
            String columna[] = {"ID DIETA","ID ANIMAL", "NOMBRE CIENTIFICO", "NOMBRE VULGAR", "FECHA ALIMENTACION", "HORA"};
            modelo = new DefaultTableModel(datos, columna);
            TableReporteDieta.setModel(modelo);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void CargarDatos() {
        AlimentacionAnimal diet;
        Animal ani;
        try {
            for (int i = 0; i < RegistroDieta.dieta.size(); i++) {
                for (int j = 0; j < RegistroAnimal.listaanimal.size(); j++) {
                diet = (AlimentacionAnimal) RegistroDieta.dieta.get(i);
                 ani = (Animal) RegistroAnimal.listaanimal.get(j);
                modelo.insertRow(contador, new Object[]{});
                modelo.setValueAt(diet.getIdDieta(), contador, 0);
                modelo.setValueAt(diet.getIdAnimal(), contador, 1);
                modelo.setValueAt(ani.getNombre_cienti(), contador, 2);
                modelo.setValueAt(ani.getNombre_vulga(), contador, 3);
                modelo.setValueAt(diet.getFechaInicio(), contador, 4);
                modelo.setValueAt(diet.getHora(), contador, 5);
            }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableReporteDieta = new javax.swing.JTable();
        jButtonSalir = new javax.swing.JButton();
        txtConsultaReporteDieta = new javax.swing.JTextField();
        ButtonBuscarReporteDieta = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/002.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -170, 900, 240));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 51, 0));
        jLabel2.setText("REPORTE DE DIETAS");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, -1, -1));

        TableReporteDieta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID DIETA", "ID ANIMAL", "NOMBRE CIENTIFICO", "NOMBRE VULGAR", "FECHA ALIMENTACION", "HORA"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TableReporteDieta);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 860, 90));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 370, 50, 30));

        txtConsultaReporteDieta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultaReporteDietaActionPerformed(evt);
            }
        });
        jPanel1.add(txtConsultaReporteDieta, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, 350, -1));

        ButtonBuscarReporteDieta.setText("BUSCAR");
        jPanel1.add(ButtonBuscarReporteDieta, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 110, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
        Menu remenu = new Menu();
        remenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void txtConsultaReporteDietaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultaReporteDietaActionPerformed
       String valor = txtConsultaReporteDieta.getText();
   for (int i = 0; i < TableReporteDieta.getRowCount(); i++) {
            if (TableReporteDieta.getValueAt(i, 0).equals(valor)||TableReporteDieta.getValueAt(i, 1).equals(valor) ||TableReporteDieta.getValueAt(i, 2).equals(valor)||TableReporteDieta.getValueAt(i, 3).equals(valor)||TableReporteDieta.getValueAt(i, 4).equals(valor)||TableReporteDieta.getValueAt(i, 5).equals(valor)  ) {
                TableReporteDieta.changeSelection(i, 0, false, false);
                txtIdDieta.setText(String.valueOf(TableReporteDieta.getValueAt(i, 0)));
                txtIdAnimal.setText(String.valueOf(TableReporteDieta.getValueAt(i, 1)));
                txtNombreCientificoDiet.setText(String.valueOf(TableReporteDieta.getValueAt(i, 2)));
                txtNombreVulgarDiet.setText(String.valueOf(TableReporteDieta.getValueAt(i, 3)));
                txtFechaInicio.setText(String.valueOf(TableReporteDieta.getValueAt(i, 4)));
                txtHora.setText(String.valueOf(TableReporteDieta.getValueAt(i, 5)));
                 
            }
   }
    }//GEN-LAST:event_txtConsultaReporteDietaActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReporteDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReporteDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReporteDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReporteDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReporteDieta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBuscarReporteDieta;
    public static javax.swing.JTable TableReporteDieta;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTextField txtConsultaReporteDieta;
    // End of variables declaration//GEN-END:variables
}
