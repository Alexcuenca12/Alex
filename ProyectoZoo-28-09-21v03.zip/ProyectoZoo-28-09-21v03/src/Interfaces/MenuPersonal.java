
package Interfaces;

public class MenuPersonal extends javax.swing.JFrame {

    public MenuPersonal() {
        initComponents();
         this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButtonSalir = new javax.swing.JButton();
        jButtonCuidadores = new javax.swing.JButton();
        jButtonGerente = new javax.swing.JButton();
        jButtonVeterinario = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButtonLimpieza = new javax.swing.JButton();
        jButtonGuardia = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 2, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("A REGISTRAR");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, -1, -1));

        jButtonSalir.setForeground(new java.awt.Color(153, 102, 0));
        jButtonSalir.setText("SALIR");
        jButtonSalir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 70, -1));

        jButtonCuidadores.setForeground(new java.awt.Color(153, 102, 0));
        jButtonCuidadores.setText("CUIDADOR");
        jButtonCuidadores.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonCuidadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCuidadoresActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCuidadores, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 120, -1));

        jButtonGerente.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGerente.setText("GERENTE");
        jButtonGerente.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonGerente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGerenteActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGerente, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 120, -1));

        jButtonVeterinario.setForeground(new java.awt.Color(153, 102, 0));
        jButtonVeterinario.setText("VETERINARIO");
        jButtonVeterinario.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonVeterinario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVeterinarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonVeterinario, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 120, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SELECCIONE EL PERSONAL ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jButtonLimpieza.setForeground(new java.awt.Color(153, 102, 0));
        jButtonLimpieza.setText("PERSONAL LIMPIEZA");
        jButtonLimpieza.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonLimpieza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimpiezaActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonLimpieza, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 120, -1));

        jButtonGuardia.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGuardia.setText("GUARDIA");
        jButtonGuardia.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButtonGuardia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardiaActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardia, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 120, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/001.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-200, 0, 470, 360));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGerenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGerenteActionPerformed
        RegistroGerentes VentanaGe=new RegistroGerentes();
        VentanaGe.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonGerenteActionPerformed

    private void jButtonVeterinarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVeterinarioActionPerformed
         RegistroVeterinario verventanaV= new RegistroVeterinario();
        verventanaV.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonVeterinarioActionPerformed

    private void jButtonCuidadoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCuidadoresActionPerformed
       Registro_Cuidadores verventanaC= new Registro_Cuidadores();
        verventanaC.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonCuidadoresActionPerformed

    private void jButtonGuardiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardiaActionPerformed
          RegistroGuardias verventanaG= new RegistroGuardias();
        verventanaG.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonGuardiaActionPerformed

    private void jButtonLimpiezaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimpiezaActionPerformed
        RegistroPerLimp1 verventanaP= new RegistroPerLimp1();
        verventanaP.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonLimpiezaActionPerformed

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
        Menu acceso=new Menu();
        acceso.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPersonal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCuidadores;
    private javax.swing.JButton jButtonGerente;
    private javax.swing.JButton jButtonGuardia;
    private javax.swing.JButton jButtonLimpieza;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JButton jButtonVeterinario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
