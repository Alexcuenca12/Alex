/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Ventanas.*;
import Clases.DetalleLimpieza;
import Ventanas.Consultar_IdPersonal_Limp;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class Detalle_Limpieza extends javax.swing.JFrame {
//Variable estatica para consultar Area
    int consultarArea;
    public Detalle_Limpieza() {
        initComponents();
    }

    LinkedList<DetalleLimpieza> listDetalleLimpieza=new LinkedList<DetalleLimpieza>();
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        btnConsultar = new javax.swing.JButton();
        txtConsultar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        txt_idArea = new javax.swing.JTextField();
        txt_IdPersonalLimp = new javax.swing.JTextField();
        fecha = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaObserv = new javax.swing.JTextArea();
        Pendiente = new javax.swing.JRadioButton();
        Limpio = new javax.swing.JRadioButton();
        btnAtras = new javax.swing.JButton();
        txtFecha = new javax.swing.JTextField();
        BtnBuscarIdPlimp = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("DETALLE DE LIMPIEZA");

        btnConsultar.setText("CONSULTAR:");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        jLabel3.setText("ID PERSONAL LIMPIEZA:");

        jLabel4.setText("ID AREA:");

        jLabel5.setText("FECHA:");

        jLabel6.setText("OBSERVACIONES:");

        jLabel7.setText("ESTADO:");

        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jTextAreaObserv.setColumns(20);
        jTextAreaObserv.setRows(5);
        jScrollPane1.setViewportView(jTextAreaObserv);

        buttonGroup1.add(Pendiente);
        Pendiente.setText("Pendiente");

        buttonGroup1.add(Limpio);
        Limpio.setText("Limpio");

        btnAtras.setText("ATRAS");
        btnAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasActionPerformed(evt);
            }
        });

        BtnBuscarIdPlimp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BtnBuscarIdPlimp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarIdPlimpActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addComponent(btnActualizar)
                        .addGap(55, 55, 55)
                        .addComponent(btnGuardar)
                        .addGap(62, 62, 62)
                        .addComponent(btnEliminar))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnAtras)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(45, 45, 45))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(txtConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)))
                        .addComponent(btnConsultar)))
                .addContainerGap(108, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtFecha)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(txt_idArea, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                    .addComponent(txt_IdPersonalLimp)
                    .addComponent(fecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BtnBuscarIdPlimp)
                .addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addContainerGap(233, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(Pendiente)
                                .addGap(18, 18, 18)
                                .addComponent(Limpio))
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsultar)
                    .addComponent(txtConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAtras))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Pendiente)
                    .addComponent(Limpio)
                    .addComponent(txt_idArea, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_IdPersonalLimp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnBuscarIdPlimp))
                        .addGap(26, 26, 26)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnActualizar)
                            .addComponent(btnGuardar)
                            .addComponent(btnEliminar))
                        .addGap(32, 32, 32))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        txt_IdPersonalLimp.setEnabled(true);
        txt_idArea.setEnabled(true);
        int res= JOptionPane.showConfirmDialog(Detalle_Limpieza.this, "Esta seguro de modificar este registro", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String IdArea=txt_idArea.getText();
                String IdPersonalLimp=txt_IdPersonalLimp.getText();
                String fecha=getFecha(this.fecha);
                String Estado=Opcionlimpieza();
                String Observacion=jTextAreaObserv.getText();
                //Validaciones de datos
                if (jTextAreaObserv.getText().isEmpty()||txt_idArea.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "llene todos los campos porfavor");
                }else{
                 DetalleLimpieza detalleLimp=new DetalleLimpieza(IdPersonalLimp, IdArea, fecha, Observacion, Estado);
                 listDetalleLimpieza.set(consultarArea, detalleLimp);
                 JOptionPane.showMessageDialog(null, "Se ha modificado correctamente los datos");
                 LimpiarDatos();
                }
            }catch(Exception e){
                System.out.println(e);
            }
        }
        LimpiarDatos();
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnGuardar.setEnabled(true);
        txt_idArea.setEnabled(true);
        txt_IdPersonalLimp.setEnabled(true);

    }//GEN-LAST:event_btnActualizarActionPerformed
    public void LimpiarDatos(){
        txt_idArea.setText("");
        txt_IdPersonalLimp.setText("");
        buttonGroup1.clearSelection();
        jTextAreaObserv.setText("");
    }
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
       String consultar=txtConsultar.getText().trim();
       //Bandera para comprobar si es encontro o no encontro
       boolean encontro=false;
        for (int i = 0; i < listDetalleLimpieza.size(); i++) {
            if (listDetalleLimpieza.get(i).getIdArea().equalsIgnoreCase(consultar)) {
                txt_IdPersonalLimp.setEnabled(false);
                txt_idArea.setEnabled(false);
                    btnGuardar.setEnabled(false);
                    btnActualizar.setEnabled(true);
                    btnEliminar.setEnabled(false);
                    //Mostramos los datos que corresponden al ID ingresado
                    txt_IdPersonalLimp.setText(listDetalleLimpieza.get(i).getDniLimpieza());
                    txt_idArea.setText(listDetalleLimpieza.get(i).getIdArea());
                    jTextAreaObserv.setText(listDetalleLimpieza.get(i).getObservaciones());
                    txtFecha.setText(listDetalleLimpieza.get(i).getFecha());
                    if (listDetalleLimpieza.get(i).getEstado().equalsIgnoreCase("Pendiente")) {
                    Pendiente.setSelected(true);
                }else{
                        Limpio.setSelected(true);
                    }
                    JOptionPane.showMessageDialog(null, "Se encontro el Area");
                    encontro=true;
                    consultarArea=i;
                    i=listDetalleLimpieza.size();
            }
        }
        if (!encontro) {
            JOptionPane.showMessageDialog(null, "No Se ha encontrado el Area");
        }
        txtConsultar.setText("");
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        String IdArea=txt_idArea.getText();
        String IdPersonalLimpieza=txt_IdPersonalLimp.getText();
        String Fecha=getFecha(fecha);
        String estado=Opcionlimpieza();
        String Observacion=jTextAreaObserv.getText();
        
        if (txt_idArea.getText().isEmpty()||txt_IdPersonalLimp.getText().isEmpty()||jTextAreaObserv.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Porfavor rellene todos los datos");
        }else{
        DetalleLimpieza detalleL=new DetalleLimpieza(IdPersonalLimpieza, IdArea, Fecha, Observacion, estado);
        listDetalleLimpieza.add(detalleL);
        JOptionPane.showMessageDialog(null, "Se ha guardado correctamente los datos");
         //Limpiar campos
        LimpiarDatos();
        }
       
        
    }//GEN-LAST:event_btnGuardarActionPerformed
     //Metodo para verificar botones de estado de limpieza
    public String Opcionlimpieza() {
        String opcion = null;
        if (Pendiente.isSelected()) {
            opcion = "Pendiente";
        }
        if (Limpio.isSelected()) {
            opcion = "Limpio";
        }
        return opcion;
    }
    
    //Metodo para pasar el formato de fecha
    SimpleDateFormat formato=new SimpleDateFormat("dd-MM-yyyy");
    public String getFecha(JDateChooser jd){
        if (jd.getDate()!=null) {
            return formato.format(jd.getDate());
        }else{
            return null;
        }
    }
    private void btnAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasActionPerformed
        Menu acceso=new Menu();
        acceso.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnAtrasActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
    int res= JOptionPane.showConfirmDialog(Detalle_Limpieza.this, "Esta seguro de eliminar este registro", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroPerLimp1.listPersLimp.remove();
                LimpiarDatos();
                JOptionPane.showMessageDialog(null, "Registro eliminado");
            }catch (Exception e) {
                System.out.println(e);
        }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void BtnBuscarIdPlimpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarIdPlimpActionPerformed
    Consultar_IdPersonal_Limp acceso=new Consultar_IdPersonal_Limp();
    acceso.setVisible(true);
    }//GEN-LAST:event_BtnBuscarIdPlimpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Detalle_Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Detalle_Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Detalle_Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Detalle_Limpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Detalle_Limpieza().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscarIdPlimp;
    private javax.swing.JRadioButton Limpio;
    private javax.swing.JRadioButton Pendiente;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAtras;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.toedter.calendar.JDateChooser fecha;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaObserv;
    private javax.swing.JTextField txtConsultar;
    private javax.swing.JTextField txtFecha;
    public static javax.swing.JTextField txt_IdPersonalLimp;
    public static javax.swing.JTextField txt_idArea;
    // End of variables declaration//GEN-END:variables
}
