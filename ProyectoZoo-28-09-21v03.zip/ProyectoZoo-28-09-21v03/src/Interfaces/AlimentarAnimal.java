
package Interfaces;

import Clases.AlimentacionAnimal;
import Clases.Animal;
import Clases.ProductoAlimento;
import static Interfaces.RegistroAnimal.listaanimal;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import static Interfaces.Registros_ProductosAlimenticios.listProAlimenticios;


public class AlimentarAnimal extends javax.swing.JFrame {
   public static LinkedList<AlimentacionAnimal> dieta = new LinkedList<AlimentacionAnimal>();
    public int buscar;
AlimentacionAnimal ddiet=null;
Animal datos=null;
ProductoAlimento dts=null;
    public AlimentarAnimal() {
        initComponents();
           setLocationRelativeTo(null);
        //Animal
        txtIdDieta.setEnabled(false);
        txtIdAnimal.setEnabled(false);
        txtNombreCientificoAl.setEnabled(false);
        txtNombreVulgarAL.setEnabled(false);
        /////Producto
        txtIdProducto.setEnabled(false);
        txtNombreProdDiet.setEnabled(false);
        txtValorNutriDiet.setEnabled(false);
        ComboBoxUnidadMedida.setEnabled(false);
        txtCantidadProd.setEnabled(false);
        ///
        fechaAlimentacionInicio.setEnabled(false);
        txtHora.setEnabled(false);

    
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtCantidadProd = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtIdAnimal = new javax.swing.JTextField();
        jButtonConsultar = new javax.swing.JButton();
        txtIdDieta = new javax.swing.JTextField();
        jButtonGuardar = new javax.swing.JButton();
        jButtonSalir = new javax.swing.JButton();
        jButtonActualizar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        ComboBoxUnidadMedida = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        fechaAlimentacionInicio = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtNombreCientificoAl = new javax.swing.JTextField();
        txtNombreVulgarAL = new javax.swing.JTextField();
        txtNombreProdDiet = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtHora = new javax.swing.JFormattedTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel20 = new javax.swing.JLabel();
        ComboEstadoAlimentacion = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txtValorNutriDiet = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtIdProducto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButtonSalir1 = new javax.swing.JButton();
        txtConsultar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCantidadProd.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtCantidadProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadProdActionPerformed(evt);
            }
        });
        jPanel1.add(txtCantidadProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 110, 20));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 51, 0));
        jLabel2.setText(" ALIMENTAR ANIMAL");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 120, -1, -1));
        jPanel1.add(txtIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 120, 20));

        jButtonConsultar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonConsultar.setText("consultar");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, 100, -1));

        txtIdDieta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdDietaActionPerformed(evt);
            }
        });
        jPanel1.add(txtIdDieta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 120, -1));

        jButtonGuardar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 450, -1, -1));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 460, -1, 30));

        jButtonActualizar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 450, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/005.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-410, 0, -1, 70));

        jLabel6.setForeground(new java.awt.Color(153, 102, 0));
        jLabel6.setText("ID DIETA");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        ComboBoxUnidadMedida.setForeground(new java.awt.Color(102, 51, 0));
        ComboBoxUnidadMedida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "KILOGRAMOS", "LIBRAS" }));
        jPanel1.add(ComboBoxUnidadMedida, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 380, 100, -1));

        jLabel10.setForeground(new java.awt.Color(153, 102, 0));
        jLabel10.setText("CANTIDAD");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, -1, -1));
        jPanel1.add(fechaAlimentacionInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, 120, 20));

        jLabel12.setForeground(new java.awt.Color(153, 102, 0));
        jLabel12.setText("FECHA INICIO");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, -1, -1));

        jLabel8.setForeground(new java.awt.Color(153, 102, 0));
        jLabel8.setText("ID ANIMAL");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        jLabel15.setForeground(new java.awt.Color(153, 102, 0));
        jLabel15.setText("NOMBRE CIENTIFICO");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 180, -1, -1));

        jLabel17.setForeground(new java.awt.Color(153, 102, 0));
        jLabel17.setText("ESTADO DE ALIMENTACIÓN");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 380, -1, -1));

        txtNombreCientificoAl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreCientificoAlActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombreCientificoAl, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, 120, -1));
        jPanel1.add(txtNombreVulgarAL, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 180, 90, -1));
        jPanel1.add(txtNombreProdDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 330, 90, 20));

        jLabel19.setForeground(new java.awt.Color(153, 102, 0));
        jLabel19.setText("HORA ALIMENTACION");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 230, -1, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 208, 1010, -1));

        try {
            txtHora.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 230, 100, -1));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 296, 1010, 20));

        jLabel20.setForeground(new java.awt.Color(153, 102, 0));
        jLabel20.setText("NOMBRE PRODUCTO");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, -1, -1));

        ComboEstadoAlimentacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "ALIMENTADO", "PENDIENTE" }));
        jPanel1.add(ComboEstadoAlimentacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 380, -1, -1));

        jLabel18.setForeground(new java.awt.Color(153, 102, 0));
        jLabel18.setText("NOMBRE VULGAR");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, -1, -1));

        jLabel21.setForeground(new java.awt.Color(153, 102, 0));
        jLabel21.setText("VALOR NUTRICIONAL");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 330, -1, -1));
        jPanel1.add(txtValorNutriDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 330, 100, -1));

        jLabel4.setForeground(new java.awt.Color(153, 102, 0));
        jLabel4.setText("CALORIAS");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 330, -1, -1));
        jPanel1.add(txtIdProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 80, -1));

        jLabel13.setForeground(new java.awt.Color(153, 102, 0));
        jLabel13.setText("ID PRODUCTO");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));

        jButtonSalir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir1.setBorder(null);
        jButtonSalir1.setContentAreaFilled(false);
        jButtonSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalir1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(741, 460, 30, 30));
        jPanel1.add(txtConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 80, 180, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 782, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCantidadProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadProdActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
   try {
            String consultar = txtConsultar.getText().trim();
            String idAn=txtIdAnimal.getText();
            String idProd=txtIdProducto.getText();
        boolean encontrar = false;
         boolean encontrar2 = false;
          boolean encontrar3 = false;
       
            for (int i = 0; i <dieta.size(); i++) {
                if (dieta.get(i).getIdDieta().equalsIgnoreCase(consultar)) {
                  ddiet=dieta.get(i);
                  encontrar=true;
                }
                 if (encontrar == true) {
                    txtIdDieta.setText(ddiet.getIdDieta());
                    txtIdAnimal.setText(ddiet.getIdAnimal());
                    txtIdProducto.setText(ddiet.getIdProducto());
                    txtCantidadProd.setText(ddiet.getCantidad());
                    txtHora.setText(ddiet.getHora());
                    fechaAlimentacionInicio.setText(ddiet.getFechaInicio());
                     ComboBoxUnidadMedida.setSelectedItem(ddiet.getUmedida());
                     ComboEstadoAlimentacion.setSelectedItem(ddiet.getEstadoAlimentacion());
            
                     buscar = i;
                     
                    JOptionPane.showMessageDialog(null, "Se ha encontrado la ALIMENTACION");
                }else{
                    JOptionPane.showMessageDialog(null, "No Se ha encontrado la ALIMENTACION"); 
                }
            }
                      for (int i = 0; i < RegistroAnimal.listaanimal.size(); i++) {
                    Animal ani;
                    ani = (Animal) RegistroAnimal.listaanimal.get(i);
                    if (idAn.equalsIgnoreCase(ani.getIdAnimal())) {
                        datos=listaanimal.get(i);
                       encontrar2=true;
                    }
                    if(encontrar2==true){
                         txtNombreCientificoAl.setText(datos.getNombre_cienti());
                         txtNombreVulgarAL.setText(datos.getNombre_vulga());
                    }
                }
                          for (int i = 0; i < Registros_ProductosAlimenticios.listProAlimenticios.size(); i++) {
                    ProductoAlimento prodA;
                    prodA = (ProductoAlimento) Registros_ProductosAlimenticios.listProAlimenticios.get(i);
                    if (idProd.equalsIgnoreCase(prodA.getIdProducto())) {
                        dts=listProAlimenticios.get(i);
                       encontrar3=true;
                    }
                    if(encontrar3==true){
                         txtNombreProdDiet.setText(dts.getNombre());
                         txtValorNutriDiet.setText(dts.getValorNutricional());
                    }
                          }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultar.setText("");
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void txtIdDietaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdDietaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdDietaActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
                System.out.println("Se ha presinado el Boton guardar");
        try {
            if (ComboEstadoAlimentacion.getSelectedItem().equals("Seleccione")) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String idDieta = txtIdDieta.getText();
                String idAnimal=txtIdAnimal.getText();
                String idProducto=txtIdProducto.getText();
                String Cant = txtCantidadProd.getText();
                String h = txtHora.getText();
                String fechaAlim =fechaAlimentacionInicio.getText();
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
                String estadoA= ComboEstadoAlimentacion.getSelectedItem().toString();

                    AlimentacionAnimal ddieta = new AlimentacionAnimal(idDieta, idAnimal, Cant, idProducto, Umed, fechaAlim, h,estadoA);
                    dieta.add(ddieta);
                    System.out.println(dieta);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    
                
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
        Menu remenu = new Menu();
        remenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
        int res = JOptionPane.showConfirmDialog(AlimentarAnimal.this, "Esta seguro de Modificar los datos \nde esta Alimentacion", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String idDieta = txtIdDieta.getText();
                String idAnimal = txtIdAnimal.getText();
                String idProducto = txtIdProducto.getText();
                String Cant = txtCantidadProd.getText();
                String fechaAlim= fechaAlimentacionInicio.getText();
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
                String h=txtHora.getText();
                String estadoA= ComboEstadoAlimentacion.getSelectedItem().toString();
                AlimentacionAnimal ddiet = new AlimentacionAnimal(idDieta,idAnimal,Cant,idProducto,fechaAlim,Umed,h,estadoA);
                RegistroDieta.dieta.set(buscar, ddiet);
                JOptionPane.showMessageDialog(null, "Alimentacion Modificada");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void txtNombreCientificoAlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreCientificoAlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreCientificoAlActionPerformed

    private void jButtonSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalir1ActionPerformed
        Menu remenu = new Menu();
        remenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalir1ActionPerformed
    public void LimpiarDatos() {
        //limpiar datos
        txtIdDieta.setText("");
        txtIdAnimal.setText("");
        txtCantidadProd.setText("");
        txtIdProducto.setText("");
        txtHora.setText("");
        fechaAlimentacionInicio.setText("");
        ComboBoxUnidadMedida.setSelectedItem("Seleccione");
        ComboEstadoAlimentacion.setSelectedItem("Seleccione");
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AlimentarAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AlimentarAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AlimentarAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AlimentarAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AlimentarAnimal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxUnidadMedida;
    private javax.swing.JComboBox<String> ComboEstadoAlimentacion;
    public static javax.swing.JTextField fechaAlimentacionInicio;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JButton jButtonSalir1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    public static javax.swing.JTextField txtCantidadProd;
    private javax.swing.JTextField txtConsultar;
    private javax.swing.JFormattedTextField txtHora;
    public static javax.swing.JTextField txtIdAnimal;
    public static javax.swing.JTextField txtIdDieta;
    public static javax.swing.JTextField txtIdProducto;
    public static javax.swing.JTextField txtNombreCientificoAl;
    public static javax.swing.JTextField txtNombreProdDiet;
    public static javax.swing.JTextField txtNombreVulgarAL;
    private javax.swing.JTextField txtValorNutriDiet;
    // End of variables declaration//GEN-END:variables
}
