package Interfaces;

import Clases.Animal;
import Clases.AlimentacionAnimal;
import Clases.Productos;
import Ventanas.ConsultaIdAnimal;
import Ventanas.ConsultaIdProducto;
import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.JOptionPane;

public class RegistroDieta extends javax.swing.JFrame {
  SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    public static LinkedList<AlimentacionAnimal> dieta = new LinkedList<AlimentacionAnimal>();
    public int buscar;
AlimentacionAnimal ddiet=null;
    public RegistroDieta() {
        initComponents();
        setLocationRelativeTo(null);
        //Animal
        txtIdAnimal.setEnabled(false);
        txtNombreCientificoDiet.setEnabled(false);
        txtNombreVulgarDiet.setEnabled(false);
        txtPesoDiet.setEnabled(false);
        txtEspecieDiet.setEnabled(false);
        /////Producto
        txtIdProducto.setEnabled(false);
        txtNombreProdDiet.setEnabled(false);
        txtValorNutriDiet.setEnabled(false);
       // ComboEstadoAlimentacion.setEnabled(false);
        txtFechaInicio.setVisible(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        txtCantidadProd = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtConsultar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtIdAnimal = new javax.swing.JTextField();
        jButtonEliminar = new javax.swing.JButton();
        txtIdDieta = new javax.swing.JTextField();
        jButtonGuardar = new javax.swing.JButton();
        jButtonConsultar = new javax.swing.JButton();
        jButtonSalir = new javax.swing.JButton();
        jButtonActualizar = new javax.swing.JButton();
        BConsultarIdAnimal = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BConsultarIdProducto = new javax.swing.JButton();
        txtIdProducto = new javax.swing.JTextField();
        ComboBoxUnidadMedida = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        fechaAlimentacionInicio = new com.toedter.calendar.JDateChooser();
        txtFechaInicio = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtNombreVulgarDiet = new javax.swing.JTextField();
        txtPesoDiet = new javax.swing.JTextField();
        txtEspecieDiet = new javax.swing.JTextField();
        txtNombreProdDiet = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        txtValorNutriDiet = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtHora = new javax.swing.JFormattedTextField();
        txtNombreCientificoDiet = new javax.swing.JTextField();
        ComboEstadoAlimentacion = new javax.swing.JComboBox<>();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItemAlimentarAnimal = new javax.swing.JMenuItem();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCantidadProd.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtCantidadProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadProdActionPerformed(evt);
            }
        });
        jPanel1.add(txtCantidadProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 100, 20));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 51, 0));
        jLabel2.setText("REGISTRO DE ALIMENTACIÓN");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, -1, -1));

        txtConsultar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPanel1.add(txtConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 80, 140, 20));

        jLabel4.setForeground(new java.awt.Color(153, 102, 0));
        jLabel4.setText("CALORIAS");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 340, -1, -1));
        jPanel1.add(txtIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 120, 20));

        jButtonEliminar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonEliminar.setText("ELIMINAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 450, 100, -1));

        txtIdDieta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdDietaActionPerformed(evt);
            }
        });
        jPanel1.add(txtIdDieta, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 120, -1));

        jButtonGuardar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 450, -1, -1));

        jButtonConsultar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonConsultar.setText("CONSULTAR");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 80, -1, 20));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 440, -1, 30));

        jButtonActualizar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 450, -1, -1));

        BConsultarIdAnimal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdAnimal.setBorderPainted(false);
        BConsultarIdAnimal.setContentAreaFilled(false);
        BConsultarIdAnimal.setDefaultCapable(false);
        BConsultarIdAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdAnimalActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 30, 40));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/005.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 70));

        jLabel6.setForeground(new java.awt.Color(153, 102, 0));
        jLabel6.setText("ID DIETA");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, -1));

        BConsultarIdProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdProducto.setBorderPainted(false);
        BConsultarIdProducto.setContentAreaFilled(false);
        BConsultarIdProducto.setDefaultCapable(false);
        BConsultarIdProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdProductoActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 330, 30, 40));
        jPanel1.add(txtIdProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 340, 100, -1));

        ComboBoxUnidadMedida.setForeground(new java.awt.Color(102, 51, 0));
        ComboBoxUnidadMedida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "KILOGRAMOS", "LIBRAS" }));
        jPanel1.add(ComboBoxUnidadMedida, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, 100, -1));

        jLabel10.setForeground(new java.awt.Color(153, 102, 0));
        jLabel10.setText("CANTIDAD");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, -1, -1));
        jPanel1.add(fechaAlimentacionInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 120, 20));
        jPanel1.add(txtFechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 120, 20));

        jLabel12.setForeground(new java.awt.Color(153, 102, 0));
        jLabel12.setText("FECHA ALIMENTACIÓN");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, -1, -1));

        jLabel8.setForeground(new java.awt.Color(153, 102, 0));
        jLabel8.setText("ID ANIMAL");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, -1, -1));

        jLabel13.setForeground(new java.awt.Color(153, 102, 0));
        jLabel13.setText("ID PRODUCTO");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, -1, -1));

        jLabel15.setForeground(new java.awt.Color(153, 102, 0));
        jLabel15.setText("NOMBRE CIENTIFICO");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, -1, -1));

        jLabel16.setForeground(new java.awt.Color(153, 102, 0));
        jLabel16.setText("TIPO ESPECIE");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 220, -1, -1));

        jLabel17.setForeground(new java.awt.Color(153, 102, 0));
        jLabel17.setText("NOMBRE VULGAR");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 220, -1, -1));
        jPanel1.add(txtNombreVulgarDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 220, 120, -1));
        jPanel1.add(txtPesoDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 180, 100, -1));
        jPanel1.add(txtEspecieDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 220, 100, -1));
        jPanel1.add(txtNombreProdDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 340, 100, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 248, 1010, 10));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 1010, 20));

        jLabel20.setForeground(new java.awt.Color(153, 102, 0));
        jLabel20.setText("ESTADO DE LA ALIMENTACION");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 390, -1, -1));

        jLabel21.setForeground(new java.awt.Color(153, 102, 0));
        jLabel21.setText("VALOR NUTRICIONAL");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 340, -1, -1));

        jLabel22.setForeground(new java.awt.Color(153, 102, 0));
        jLabel22.setText("NOMBRE PRODUCTO");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 340, -1, -1));
        jPanel1.add(txtValorNutriDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 340, 100, -1));

        jLabel7.setForeground(new java.awt.Color(153, 102, 0));
        jLabel7.setText("PESO");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, -1, -1));

        jLabel19.setForeground(new java.awt.Color(153, 102, 0));
        jLabel19.setText("HORA ALIMENTACION");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, -1, -1));

        try {
            txtHora.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 280, 100, -1));
        jPanel1.add(txtNombreCientificoDiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 180, 120, 20));

        ComboEstadoAlimentacion.setForeground(new java.awt.Color(102, 51, 0));
        ComboEstadoAlimentacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "ALIMENTADO", "PENDIENTE" }));
        jPanel1.add(ComboEstadoAlimentacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 390, 90, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 500));

        jMenu3.setText("OPCIONES");

        jMenuItemAlimentarAnimal.setText("ALIMENTAR ANIMAL");
        jMenuItemAlimentarAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAlimentarAnimalActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItemAlimentarAnimal);

        jMenuBar2.add(jMenu3);

        setJMenuBar(jMenuBar2);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
       Menu remenu = new Menu();
        remenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
        txtFechaInicio.setVisible(true);
        try {
            String consultar = txtConsultar.getText().trim();
        boolean encontrar = false;
       
            for (int i = 0; i <dieta.size(); i++) {
                if (dieta.get(i).getIdDieta().equalsIgnoreCase(consultar)) {
                  ddiet=dieta.get(i);
                  encontrar=true;
                }
                 if (encontrar == true) {
                    txtIdDieta.setText(ddiet.getIdDieta());
                    txtIdAnimal.setText(ddiet.getIdAnimal());
                    txtIdProducto.setText(ddiet.getIdProducto());
                    txtCantidadProd.setText(ddiet.getCantidad());
                    txtHora.setText(ddiet.getHora());
                     txtFechaInicio.setText(ddiet.getFechaInicio());
//                    Date date= new SimpleDateFormat("dd/MM/yyyy").parse((String)toString());
//                    txtFecha.setText(date);
                     ComboBoxUnidadMedida.setSelectedItem(ddiet.getUmedida());
                     buscar = i;
                    JOptionPane.showMessageDialog(null, "Se ha encontrado la ALIMENTACION");
                }
                 if(!encontrar){
                    JOptionPane.showMessageDialog(null, "No Se ha encontrado la ALIMENTACION"); 
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultar.setText("");
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
        int res = JOptionPane.showConfirmDialog(RegistroDieta.this, "Esta seguro de Modificar los datos \nde esta ALIMENTACION", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String idDieta = txtIdDieta.getText();
                String idAnimal = txtIdAnimal.getText();
                String idProducto = txtIdProducto.getText();
                String Cant = txtCantidadProd.getText();
               String fechaAlim= formato.format(fechaAlimentacionInicio.getDate());
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
                String h=txtHora.getText();
                String estadoA= ComboEstadoAlimentacion.getSelectedItem().toString();
                AlimentacionAnimal ddiet = new AlimentacionAnimal(idDieta,idAnimal,Cant,idProducto,fechaAlim,Umed,h,estadoA);
                RegistroDieta.dieta.set(buscar, ddiet);
                JOptionPane.showMessageDialog(null, "Alimentación Modificada");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
            System.out.println("Se ha presinado el Boton guardar");
        String CAnimal=txtIdAnimal.getText().trim();
        String CProducto= txtIdProducto.getText();
        boolean resp=false;
        boolean resp2=false;
        try {
            if (txtIdAnimal.getText().equals("") || txtIdDieta.getText().equals("") || txtIdProducto.getText().equals("") | txtCantidadProd.getText().equals("") || txtCantidadProd.getText().equals("") || txtHora.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String idDieta = txtIdDieta.getText();
                String idAnimal=txtIdAnimal.getText();
                String idProducto=txtIdProducto.getText();
                String Cant = txtCantidadProd.getText();
                String h = txtHora.getText();
                String fechaAlim = formato.format(fechaAlimentacionInicio.getDate());
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
                String estadoA= ComboEstadoAlimentacion.getSelectedItem().toString();
//
                for (int i = 0; i < Registros_ProductosAlimenticios.listProAlimenticios.size(); i++) {
                    Productos pro;
                    pro = (Productos) Registros_ProductosAlimenticios.listProAlimenticios.get(i);
                    if (CProducto.equalsIgnoreCase(pro.getIdProducto())) {
                        idProducto = CProducto;
                        resp=true;
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha encontrado el IdProducto");

                    }
                }
                
                for (int i = 0; i < RegistroAnimal.listaanimal.size(); i++) {
                    Animal ani;
                    ani = (Animal) RegistroAnimal.listaanimal.get(i);
                    if (CAnimal.equalsIgnoreCase(ani.getIdAnimal())) {
                        idAnimal = CAnimal;
                        resp2=true;
                        
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha encontrado el IdAnimal");
                    }
                }
                    if(resp=true){
                    if(resp2=true){
                    AlimentacionAnimal ddieta = new AlimentacionAnimal(idDieta, idAnimal, Cant, idProducto, Umed, fechaAlim, h,estadoA);
                    dieta.add(ddieta);
                    System.out.println(dieta);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    }else{
                     JOptionPane.showMessageDialog(null, "NO SE HA PODIDO REGISTRAR LA ALIMENTACION \nNO EXISTE EL ID DEL ANIMAL INGRESADO"); 
                    }
                    }else{
                     JOptionPane.showMessageDialog(null, "NO SE HA PODIDO REGISTRAR LA ALIMENTACION \nNO EXISTE EL ID DEL PRODUCTO INGRESADO"); 
                    }
                
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
        int res = JOptionPane.showConfirmDialog(RegistroDieta.this, "Esta seguro de eliminar esta ALIMENTACION", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroDieta.dieta.remove(buscar);

                   LimpiarDatos();

                JOptionPane.showMessageDialog(null, "ALIMENTACION Eliminada");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void txtIdDietaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdDietaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdDietaActionPerformed

    private void BConsultarIdAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdAnimalActionPerformed
                System.out.println("Ha presionado buscar id animal");
                ConsultaIdAnimal verveid=new ConsultaIdAnimal();
                verveid.setVisible(true);
    }//GEN-LAST:event_BConsultarIdAnimalActionPerformed

    private void BConsultarIdProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdProductoActionPerformed
         System.out.println("Ha presionado buscar id producto");
                ConsultaIdProducto verveidP=new ConsultaIdProducto();
                verveidP.setVisible(true);
    }//GEN-LAST:event_BConsultarIdProductoActionPerformed

    private void txtCantidadProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadProdActionPerformed

    private void jMenuItemAlimentarAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAlimentarAnimalActionPerformed
           AlimentarAnimal AAmenu = new AlimentarAnimal();
       AAmenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jMenuItemAlimentarAnimalActionPerformed

    public void LimpiarDatos() {
        //limpiar datos
        txtIdDieta.setText("");
        txtIdAnimal.setText("");
        txtCantidadProd.setText("");
         txtIdProducto.setText("");
         txtHora.setText("");
         fechaAlimentacionInicio.setCalendar(null);
        ComboBoxUnidadMedida.setSelectedItem("Seleccione");
        ComboEstadoAlimentacion.setSelectedItem("Seleccione");

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroDieta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BConsultarIdAnimal;
    private javax.swing.JButton BConsultarIdProducto;
    private javax.swing.JComboBox<String> ComboBoxUnidadMedida;
    public static javax.swing.JComboBox<String> ComboEstadoAlimentacion;
    private com.toedter.calendar.JDateChooser fechaAlimentacionInicio;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItemAlimentarAnimal;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    public static javax.swing.JTextField txtCantidadProd;
    public static javax.swing.JTextField txtConsultar;
    public static javax.swing.JTextField txtEspecieDiet;
    public static javax.swing.JTextField txtFechaInicio;
    public static javax.swing.JFormattedTextField txtHora;
    public static javax.swing.JTextField txtIdAnimal;
    public static javax.swing.JTextField txtIdDieta;
    public static javax.swing.JTextField txtIdProducto;
    public static javax.swing.JTextField txtNombreCientificoDiet;
    public static javax.swing.JTextField txtNombreProdDiet;
    public static javax.swing.JTextField txtNombreVulgarDiet;
    public static javax.swing.JTextField txtPesoDiet;
    public static javax.swing.JTextField txtValorNutriDiet;
    // End of variables declaration//GEN-END:variables
}
