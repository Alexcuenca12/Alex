
package Clases;

public class ProductoLimpieza extends Productos{
   private String composicion; 

    public ProductoLimpieza() {
        super();
    }

    public ProductoLimpieza(String composicion) {
        this.composicion = composicion;
    }

    public ProductoLimpieza(String composicion, String idProducto, String nombre, String descripcion, double precio, String fechaCaducacion, String tipo, String stock, String NifProveedor) {
        super(idProducto, nombre, descripcion, precio, fechaCaducacion, tipo, stock, NifProveedor);
        this.composicion = composicion;
    }

    public String getComposicion() {
        return composicion;
    }

    public void setComposicion(String composicion) {
        this.composicion = composicion;
    }

    @Override
    public String toString() {
        return super.toString()+ "composicion=" + composicion + '}';
    }
   
}
