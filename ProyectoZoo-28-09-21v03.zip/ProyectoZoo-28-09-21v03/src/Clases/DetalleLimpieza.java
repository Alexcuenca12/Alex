
package Clases;
//Atributos 
public class DetalleLimpieza {
   private String DniLimpieza;
   private String idArea;
   private String fecha;
   private String observaciones;
   private String estado;

   //Constructores
    public DetalleLimpieza() {
    }

    public DetalleLimpieza(String DniLimpieza, String idArea, String fecha, String observaciones, String estado) {
        this.DniLimpieza = DniLimpieza;
        this.idArea = idArea;
        this.fecha = fecha;
        this.observaciones = observaciones;
        this.estado = estado;
    }

    public String getDniLimpieza() {
        return DniLimpieza;
    }

    public void setDniLimpieza(String DniLimpieza) {
        this.DniLimpieza = DniLimpieza;
    }

    public String getIdArea() {
        return idArea;
    }

    public void setIdArea(String idArea) {
        this.idArea = idArea;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "DetalleLimpieza{" + "DniLimpieza=" + DniLimpieza + ", idArea=" + idArea + ", fecha=" + fecha + ", observaciones=" + observaciones + ", estado=" + estado + '}';
    }

  
}