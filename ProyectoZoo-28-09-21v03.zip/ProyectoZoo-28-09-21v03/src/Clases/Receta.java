
package Clases;

public class Receta {
  private String idReceta;  
  private String idAnimal;
  private String DniVeterinario;
  private String fechaEmision;
  private String indicaciones;
}
