
package Clases;

public class Visita {
  private String DNIGuardia;
private String cedulaVisitante;
private String fechaVisita;
private String horaVisita;
}
