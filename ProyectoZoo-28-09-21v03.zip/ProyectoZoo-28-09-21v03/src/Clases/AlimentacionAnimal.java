
package Clases;

public class AlimentacionAnimal{
     private String idDieta;
     private String idAnimal;
     private String cantidad; 
     private String idProducto;
     private String Umedida;
     private String fechaInicio;
     private String hora;
     private String estadoAlimentacion;

    public AlimentacionAnimal() {
        
    }

    public AlimentacionAnimal(String idDieta, String idAnimal, String cantidad, String idProducto, String Umedida, String fechaInicio, String hora, String estadoAlimentacion) {
        this.idDieta = idDieta;
        this.idAnimal = idAnimal;
        this.cantidad = cantidad;
        this.idProducto = idProducto;
        this.Umedida = Umedida;
        this.fechaInicio = fechaInicio;
        this.hora = hora;
        this.estadoAlimentacion = estadoAlimentacion;
    }

    public String getIdDieta() {
        return idDieta;
    }

    public void setIdDieta(String idDieta) {
        this.idDieta = idDieta;
    }

    public String getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(String idAnimal) {
        this.idAnimal = idAnimal;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getUmedida() {
        return Umedida;
    }

    public void setUmedida(String Umedida) {
        this.Umedida = Umedida;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEstadoAlimentacion() {
        return estadoAlimentacion;
    }

    public void setEstadoAlimentacion(String estadoAlimentacion) {
        this.estadoAlimentacion = estadoAlimentacion;
    }

    @Override
    public String toString() {
        return "AlimentacionAnimal{" + "idDieta=" + idDieta + ", idAnimal=" + idAnimal + ", cantidad=" + cantidad + ", idProducto=" + idProducto + ", Umedida=" + Umedida + ", fechaInicio=" + fechaInicio + ", hora=" + hora + ", estadoAlimentacion=" + estadoAlimentacion + '}';
    }

    
}