
package Clases;

public class Proveedor {
    private String NifProveedor;
    private String Nombre;
    private String apellido;
    private String telefono;
    private String correo;
    private String nombreEmpresa;

    public Proveedor() {
    }

    public Proveedor(String NifProveedor, String Nombre, String apellido, String telefono, String correo, String nombreEmpresa) {
        this.NifProveedor = NifProveedor;
        this.Nombre = Nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getNifProveedor() {
        return NifProveedor;
    }

    public void setNifProveedor(String NifProveedor) {
        this.NifProveedor = NifProveedor;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    @Override
    public String toString() {
        return "Proveedor{" + "NifProveedor=" + NifProveedor + ", Nombre=" + Nombre + ", apellido=" + apellido + ", telefono=" + telefono + ", correo=" + correo + ", nombreEmpresa=" + nombreEmpresa + '}';
    }
    
}
