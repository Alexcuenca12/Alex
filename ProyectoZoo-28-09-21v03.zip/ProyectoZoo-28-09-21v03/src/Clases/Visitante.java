
package Clases;

public class Visitante {
  private String cedula;
private String nombres;
private String apellidos;
}
