/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public class CartillaMedica {
    private String idCartilla;
    private String DniVeterinario;
    private String idReceta;
    private String idAnimal;
    private String nomEnfermedad;
    private String fechaDiagnostico;
     private String fechaCuracion;
    private String observaciones;

    public CartillaMedica() {
    }

    public CartillaMedica(String idCartilla, String DniVeterinario, String idReceta, String idAnimal, String nomEnfermedad, String fechaDiagnostico, String fechaCuracion, String observaciones) {
        this.idCartilla = idCartilla;
        this.DniVeterinario = DniVeterinario;
        this.idReceta = idReceta;
        this.idAnimal = idAnimal;
        this.nomEnfermedad = nomEnfermedad;
        this.fechaDiagnostico = fechaDiagnostico;
        this.fechaCuracion = fechaCuracion;
        this.observaciones = observaciones;
    }

    public String getIdCartilla() {
        return idCartilla;
    }

    public void setIdCartilla(String idCartilla) {
        this.idCartilla = idCartilla;
    }

    public String getDniVeterinario() {
        return DniVeterinario;
    }

    public void setDniVeterinario(String DniVeterinario) {
        this.DniVeterinario = DniVeterinario;
    }

    public String getIdReceta() {
        return idReceta;
    }

    public void setIdReceta(String idReceta) {
        this.idReceta = idReceta;
    }

    public String getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(String idAnimal) {
        this.idAnimal = idAnimal;
    }

    public String getNomEnfermedad() {
        return nomEnfermedad;
    }

    public void setNomEnfermedad(String nomEnfermedad) {
        this.nomEnfermedad = nomEnfermedad;
    }

    public String getFechaDiagnostico() {
        return fechaDiagnostico;
    }

    public void setFechaDiagnostico(String fechaDiagnostico) {
        this.fechaDiagnostico = fechaDiagnostico;
    }

    public String getFechaCuracion() {
        return fechaCuracion;
    }

    public void setFechaCuracion(String fechaCuracion) {
        this.fechaCuracion = fechaCuracion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "CartillaMedica{" + "idCartilla=" + idCartilla + ", DniVeterinario=" + DniVeterinario + ", idReceta=" + idReceta + ", idAnimal=" + idAnimal + ", nomEnfermedad=" + nomEnfermedad + ", fechaDiagnostico=" + fechaDiagnostico + ", fechaCuracion=" + fechaCuracion + ", observaciones=" + observaciones + '}';
    }


    
}