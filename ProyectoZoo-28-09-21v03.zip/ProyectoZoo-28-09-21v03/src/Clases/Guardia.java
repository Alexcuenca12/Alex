/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


public class Guardia extends Personal{
    //Atributos
    private String Jornada;
    
    //Constructores

    public Guardia() {
        super();
    }

    public Guardia(String Jornada) {
        this.Jornada = Jornada;
    }

    public Guardia(String Jornada, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo);
        this.Jornada = Jornada;
    }

    public Guardia(String Jornada, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo, String Id_TipoUsuario, String TipoUsuario, String Usuario, String Contraseña) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo, Id_TipoUsuario, TipoUsuario, Usuario, Contraseña);
        this.Jornada = Jornada;
    }

    public String getJornada() {
        return Jornada;
    }

    public void setJornada(String Jornada) {
        this.Jornada = Jornada;
    }

    @Override
    public String toString() {
        return super.toString() + Jornada;
    }

}   
