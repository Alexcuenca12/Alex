
package Clases;

public class Gerente extends Personal {
   //Atributos
    private String Idiomas;
    
   //Constructores
  
    public Gerente(String Idiomas) {
        this.Idiomas = Idiomas;
    }

    public Gerente(String Idiomas, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo);
        this.Idiomas = Idiomas;
    }

    public Gerente(String Idiomas, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo, String Id_TipoUsuario, String TipoUsuario, String Usuario, String Contraseña) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo, Id_TipoUsuario, TipoUsuario, Usuario, Contraseña);
        this.Idiomas = Idiomas;
    }
     //Getter y setter

    public String getIdiomas() {
        return Idiomas;
    }

    public void setIdiomas(String Idiomas) {
        this.Idiomas = Idiomas;
    }
    //Mostrar Datos
    @Override
    public String toString() {
        return "Gerente{" + "Idiomas=" + Idiomas + '}';
    }
    
    
}
