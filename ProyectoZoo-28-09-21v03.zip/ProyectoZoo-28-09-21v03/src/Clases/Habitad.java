
package Clases;

public class Habitad {
private String nombre;
private String idHabitad;
private String tipoEspecie; ////concetamos con especies
private String clima;
private String descripcion;

    public Habitad() {
    }

    public Habitad(String nombre, String idHabitad, String tipoEspecie, String clima, String descripcion) {
        this.nombre = nombre;
        this.idHabitad = idHabitad;
        this.tipoEspecie = tipoEspecie;
        this.clima = clima;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdHabitad() {
        return idHabitad;
    }

    public void setIdHabitad(String idHabitad) {
        this.idHabitad = idHabitad;
    }

    public String getTipoEspecie() {
        return tipoEspecie;
    }

    public void setTipoEspecie(String tipoEspecie) {
        this.tipoEspecie = tipoEspecie;
    }

    public String getClima() {
        return clima;
    }

    public void setClima(String clima) {
        this.clima = clima;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Habitad{" + "nombre=" + nombre + ", idHabitad=" + idHabitad + ", tipoEspecie=" + tipoEspecie + ", clima=" + clima + ", descripcion=" + descripcion + '}';
    }

  
    

}
