
package Clases;

public class Pedido {
    private String nifProveedor;
    private String nombreProducto;
    private int cantidad;
    private String tipoProducto;
    private String FechaPedido;
    private String DniGerente;
    
    //Constructor
    public Pedido() {
    }

    public Pedido(String nifProveedor, String nombreProducto, int cantidad, String tipoProducto, String FechaPedido, String DniGerente) {
        this.nifProveedor = nifProveedor;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.tipoProducto = tipoProducto;
        this.FechaPedido = FechaPedido;
        this.DniGerente = DniGerente;
    }

    public String getNifProveedor() {
        return nifProveedor;
    }

    public void setNifProveedor(String nifProveedor) {
        this.nifProveedor = nifProveedor;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public String getFechaPedido() {
        return FechaPedido;
    }

    public void setFechaPedido(String FechaPedido) {
        this.FechaPedido = FechaPedido;
    }

    public String getDniGerente() {
        return DniGerente;
    }

    public void setDniGerente(String DniGerente) {
        this.DniGerente = DniGerente;
    }

    @Override
    public String toString() {
        return "Pedido{" + "nifProveedor=" + nifProveedor + ", nombreProducto=" + nombreProducto + ", cantidad=" + cantidad + ", tipoProducto=" + tipoProducto + ", FechaPedido=" + FechaPedido + ", DniGerente=" + DniGerente + '}';
    }
    
}
