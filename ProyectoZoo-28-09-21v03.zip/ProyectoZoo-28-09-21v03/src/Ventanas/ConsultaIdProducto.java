
package Ventanas;

import Clases.ProductoAlimento;
import Clases.Productos;
import static Interfaces.RegistroDieta.*;
import Interfaces.Registros_ProductosAlimenticios;
import static Interfaces.Registros_ProductosAlimenticios.*;

import javax.swing.table.DefaultTableModel;


public class ConsultaIdProducto extends javax.swing.JFrame {
   private DefaultTableModel modelo;
    int cp = 0;
    public ConsultaIdProducto() {
        initComponents();
        this.setLocationRelativeTo(null);
       CargarModelo();
      CargarDatos();
    }
   private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"ID PRODUCOT","NOMBRE","VALOR NUTRICIONAL","PRECIO","STOCK"};
        modelo=new DefaultTableModel(datos,columna);
        TableConsultaidProducto.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
}
private void CargarDatos(){
    ProductoAlimento prod;
    try{
        for (int i = 0; i < Registros_ProductosAlimenticios.listProAlimenticios.size(); i++) {
            prod=(ProductoAlimento)Registros_ProductosAlimenticios.listProAlimenticios.get(i);
            modelo.insertRow(cp, new Object[]{});
            modelo.setValueAt(prod.getIdProducto(), cp, 0);
            modelo.setValueAt(prod.getNombre(), cp, 1);
            modelo.setValueAt(prod.getValorNutricional(), cp, 2);
            modelo.setValueAt(prod.getPrecio(), cp, 3);
           modelo.setValueAt(prod.getStock(), cp, 4);
           
           
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane8 = new javax.swing.JScrollPane();
        TableConsultaidProducto = new javax.swing.JTable();
        txtConsultaridProducto = new javax.swing.JTextField();
        ButtonBuscarProd = new javax.swing.JButton();
        jButtonSalir1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableConsultaidProducto.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        TableConsultaidProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "VALOR NUTRICIONAL", "PRECIO", "STOCK"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableConsultaidProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableConsultaidProductoMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(TableConsultaidProducto);

        getContentPane().add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 420, 120));
        getContentPane().add(txtConsultaridProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 160, -1));

        ButtonBuscarProd.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        ButtonBuscarProd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lupa (1).png"))); // NOI18N
        ButtonBuscarProd.setBorderPainted(false);
        ButtonBuscarProd.setContentAreaFilled(false);
        ButtonBuscarProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBuscarProdActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonBuscarProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 60, 20));

        jButtonSalir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir1.setBorder(null);
        jButtonSalir1.setContentAreaFilled(false);
        jButtonSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalir1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 20, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TableConsultaidProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableConsultaidProductoMouseClicked
        System.out.println("Ha presionado en un id de la tabla");
        int seleccionar = TableConsultaidProducto.rowAtPoint(evt.getPoint());
        txtIdProducto.setText(String.valueOf(TableConsultaidProducto.getValueAt(seleccionar, 0)));
        txtNombreProdDiet.setText(String.valueOf(TableConsultaidProducto.getValueAt(seleccionar, 1)));
        txtValorNutriDiet.setText(String.valueOf(TableConsultaidProducto.getValueAt(seleccionar, 2)));
        this.setVisible(false);


    }//GEN-LAST:event_TableConsultaidProductoMouseClicked

    private void ButtonBuscarProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBuscarProdActionPerformed
    String valor = txtConsultaridProducto.getText();
   for (int i = 0; i < TableConsultaidProducto.getRowCount(); i++) {
            if (TableConsultaidProducto.getValueAt(i, 0).equals(valor)||TableConsultaidProducto.getValueAt(i, 1).equals(valor) ||TableConsultaidProducto.getValueAt(i, 2).equals(valor)||TableConsultaidProducto.getValueAt(i, 3).equals(valor)||TableConsultaidProducto.getValueAt(i, 4).equals(valor)||TableConsultaidProducto.getValueAt(i, 5).equals(valor) ) {
                TableConsultaidProducto.changeSelection(i, 0, false, false);
                txt_idProducto.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 0)));
                txt_nombre.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 1)));
                txtValorNutricional.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 2)));
                txtPrecio.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 3)));
                txtStock.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 4)));


    }                                            
   }    
    }//GEN-LAST:event_ButtonBuscarProdActionPerformed

    private void jButtonSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalir1ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalir1ActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaIdProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBuscarProd;
    public static javax.swing.JTable TableConsultaidProducto;
    private javax.swing.JButton jButtonSalir1;
    private javax.swing.JScrollPane jScrollPane8;
    public static javax.swing.JTextField txtConsultaridProducto;
    // End of variables declaration//GEN-END:variables
}
