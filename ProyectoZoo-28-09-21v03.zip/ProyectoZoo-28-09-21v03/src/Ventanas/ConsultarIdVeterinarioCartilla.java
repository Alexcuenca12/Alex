
package Ventanas;
import Clases.Veterinario;
import static Interfaces.RegistroCartillasMedicas.*;
import Interfaces.RegistroVeterinario;
import static Interfaces.RegistroVeterinario.*;
import javax.swing.table.DefaultTableModel;
public class ConsultarIdVeterinarioCartilla extends javax.swing.JFrame {
private DefaultTableModel modelo;
    int contador = 0;
    
    public ConsultarIdVeterinarioCartilla() {
        initComponents();
        this.setLocationRelativeTo(null);
        CargarModelo();
        CargarDatos();
    }
    private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"DNI","NOMBRE","APELLIDO"};
        modelo=new DefaultTableModel(datos,columna);
        TablaConsultarVeterinario.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
}
    //Metodo para cargar DATOS
     private void CargarDatos(){
    Veterinario vet;
    try{
        for (int i = 0; i < RegistroVeterinario.listaVeterinario.size(); i++) {
            vet=(Veterinario)RegistroVeterinario.listaVeterinario.get(i);
            modelo.insertRow(contador, new Object[]{});
            modelo.setValueAt(vet.getDNI(), contador, 0);
            modelo.setValueAt(vet.getNombre(), contador, 1);
            modelo.setValueAt(vet.getApellidos(), contador, 2);
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnBuscarDNI = new javax.swing.JButton();
        txtConsultarIdVet = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaConsultarVeterinario = new javax.swing.JTable();
        jButtonSalir1 = new javax.swing.JButton();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBuscarDNI.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        btnBuscarDNI.setContentAreaFilled(false);
        btnBuscarDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarDNIActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscarDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(256, 11, -1, 21));

        txtConsultarIdVet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultarIdVetActionPerformed(evt);
            }
        });
        getContentPane().add(txtConsultarIdVet, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 11, 232, -1));

        TablaConsultarVeterinario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "DNI", "NOMBRES", "APELLIDOS"
            }
        ));
        TablaConsultarVeterinario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaConsultarVeterinarioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaConsultarVeterinario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 38, 260, 107));

        jButtonSalir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir1.setBorder(null);
        jButtonSalir1.setContentAreaFilled(false);
        jButtonSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalir1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, 30, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtConsultarIdVetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultarIdVetActionPerformed
         String valor = txtConsultarIdVet.getText();
   for (int i = 0; i < TablaConsultarVeterinario.getRowCount(); i++) {
            if (TablaConsultarVeterinario.getValueAt(i, 0).equals(valor)||TablaConsultarVeterinario.getValueAt(i, 1).equals(valor) ||TablaConsultarVeterinario.getValueAt(i, 2).equals(valor)||TablaConsultarVeterinario.getValueAt(i, 3).equals(valor)) {
                TablaConsultarVeterinario.changeSelection(i, 0, false, false);
                txtDNI.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 0)));
                txtNombres.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 1)));
                txtApellidos.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 2)));


    }                                            
   } 
    }//GEN-LAST:event_txtConsultarIdVetActionPerformed

    private void btnBuscarDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarDNIActionPerformed
        String valor=txtConsultarIdVet.getText();
        for (int i = 0; i < TablaConsultarVeterinario.getRowCount(); i++) {
             if (TablaConsultarVeterinario.getValueAt(i, 0).equals(valor)||TablaConsultarVeterinario.getValueAt(i, 1).equals(valor) ||TablaConsultarVeterinario.getValueAt(i, 2).equals(valor)) {
                TablaConsultarVeterinario.changeSelection(i, 0, false, false);
                txtDNI.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 0)));
                txtNombres.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 1)));
                txtApellidos.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(i, 2)));
        }                                            
        }
    }//GEN-LAST:event_btnBuscarDNIActionPerformed

    private void TablaConsultarVeterinarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaConsultarVeterinarioMouseClicked
       System.out.println("Ha presionado en un id de la tabla");
        int seleccionar = TablaConsultarVeterinario.rowAtPoint(evt.getPoint());
        txtIdDniVeterinarioC.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(seleccionar, 0)));
        txtNombreVetC.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(seleccionar, 1)));
        txtApellidoVetC.setText(String.valueOf(TablaConsultarVeterinario.getValueAt(seleccionar, 2)));
        this.setVisible(false);
    }//GEN-LAST:event_TablaConsultarVeterinarioMouseClicked

    private void jButtonSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalir1ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalir1ActionPerformed
     

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultarIdVeterinarioCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultarIdVeterinarioCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultarIdVeterinarioCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultarIdVeterinarioCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultarIdVeterinarioCartilla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaConsultarVeterinario;
    private javax.swing.JButton btnBuscarDNI;
    private javax.swing.JButton jButtonSalir1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtConsultarIdVet;
    // End of variables declaration//GEN-END:variables
}
