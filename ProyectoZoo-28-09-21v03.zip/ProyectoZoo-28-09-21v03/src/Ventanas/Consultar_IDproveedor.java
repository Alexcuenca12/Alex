
package Ventanas;
import Clases.Proveedor;
import Interfaces.RegistroProveedores;
import Interfaces.Pedidos;
import static Interfaces.Pedidos.txtIdproveedor;
import static Interfaces.RegistroProveedores.txtNifProveedor;
import static Interfaces.RegistroProveedores.txtNombres;
import static Interfaces.RegistroProveedores.txtApellidos;
import static Interfaces.RegistroProveedores.txtNombreEmpresa;
import javax.swing.table.DefaultTableModel;
public class Consultar_IDproveedor extends javax.swing.JFrame {
private DefaultTableModel modelo;
    int contador = 0;
   
    public Consultar_IDproveedor() {
        initComponents();
        this.setLocationRelativeTo(null);
        CargarModelo();
        CargarDatos();     
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BuscarNIF = new javax.swing.JButton();
        txtConsultarNIF = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaConsultarNIF = new javax.swing.JTable();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BuscarNIF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BuscarNIF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarNIFActionPerformed(evt);
            }
        });

        txtConsultarNIF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultarNIFActionPerformed(evt);
            }
        });

        TablaConsultarNIF.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NIF", "NOMBRE", "APELLIDO", "NOM EMPRESA"
            }
        ));
        TablaConsultarNIF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaConsultarNIFMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaConsultarNIF);

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(txtConsultarNIF, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BuscarNIF, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtConsultarNIF)
                    .addComponent(BuscarNIF, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BuscarNIFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarNIFActionPerformed
        String valor=txtConsultarNIF.getText();
        for (int i = 0; i < TablaConsultarNIF.getRowCount(); i++) {
             if (TablaConsultarNIF.getValueAt(i, 0).equals(valor)||TablaConsultarNIF.getValueAt(i, 1).equals(valor) ||TablaConsultarNIF.getValueAt(i, 2).equals(valor)||TablaConsultarNIF.getValueAt(i, 3).equals(valor)) {
                TablaConsultarNIF.changeSelection(i, 0, false, false);
                txtNifProveedor.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 0)));
                txtNombres.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 1)));
                txtApellidos.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 2)));
                txtNombreEmpresa.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 3)));
        }                                            
        }
    }//GEN-LAST:event_BuscarNIFActionPerformed

    private void TablaConsultarNIFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaConsultarNIFMouseClicked
       System.out.println("Ha presionado en un id de la tabla");
        int seleccionar = TablaConsultarNIF.rowAtPoint(evt.getPoint());
        txtIdproveedor.setText(String.valueOf(TablaConsultarNIF.getValueAt(seleccionar, 0)));
        this.setVisible(false);
    }//GEN-LAST:event_TablaConsultarNIFMouseClicked

    private void txtConsultarNIFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultarNIFActionPerformed
       String consultar=txtConsultarNIF.getText();
        for (int i = 0; i < TablaConsultarNIF.getRowCount(); i++) {
            if (TablaConsultarNIF.getValueAt(i, 0).equals(consultar)||TablaConsultarNIF.getValueAt(i, 1).equals(consultar) ||TablaConsultarNIF.getValueAt(i, 2).equals(consultar)||TablaConsultarNIF.getValueAt(i, 3).equals(consultar)) {
                TablaConsultarNIF.changeSelection(i, 0, false, false);
                txtNifProveedor.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 0)));
                txtNombres.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 1)));
                txtApellidos.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 2)));
                txtNombreEmpresa.setText(String.valueOf(TablaConsultarNIF.getValueAt(i, 3)));
            }
        }
    }//GEN-LAST:event_txtConsultarNIFActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
       this.setVisible(false);
    }//GEN-LAST:event_btnSalirActionPerformed

     //Metodo para cargar modelo tabla
    private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"NIF","NOMBRE","APELLIDO","NOMBRE EMPRESA"};
        modelo=new DefaultTableModel(datos,columna);
        TablaConsultarNIF.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
    }
    //Metodo para cargar Datos tabla
      private void CargarDatos(){
     Proveedor prov;
    try{
        for (int i = 0; i < RegistroProveedores.listaProv.size(); i++) {
            prov=(Proveedor)RegistroProveedores.listaProv.get(i);
            modelo.insertRow(contador, new Object[]{});
            modelo.setValueAt(prov.getNifProveedor(), contador, 0);
            modelo.setValueAt(prov.getNombre(), contador, 1);
            modelo.setValueAt(prov.getApellido(), contador, 2);
            modelo.setValueAt(prov.getNombreEmpresa(), contador, 3);
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consultar_IDproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consultar_IDproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consultar_IDproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consultar_IDproveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consultar_IDproveedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscarNIF;
    private javax.swing.JTable TablaConsultarNIF;
    private javax.swing.JButton btnSalir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtConsultarNIF;
    // End of variables declaration//GEN-END:variables
}
