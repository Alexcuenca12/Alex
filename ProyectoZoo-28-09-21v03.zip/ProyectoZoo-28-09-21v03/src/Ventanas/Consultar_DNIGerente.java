
package Ventanas;
import Clases.Gerente;
import Interfaces.RegistroGerentes;
import Interfaces.Pedidos;
import static Interfaces.Pedidos.txtDniGerente;
import static Interfaces.RegistroGerentes.txtDNI;
import static Interfaces.RegistroGerentes.txtNombres;
import static Interfaces.RegistroGerentes.txtApellidos;
import static Interfaces.RegistroGerentes.txtCargo;
import javax.swing.table.DefaultTableModel;
public class Consultar_DNIGerente extends javax.swing.JFrame {
private DefaultTableModel modelo;
    int cp = 0;
    /**
     * Creates new form Consultar_DNIGerente
     */
    public Consultar_DNIGerente() {
        initComponents();
        this.setLocationRelativeTo(null);
        CargarModelo();
        CargarDatos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnBuscarDNI = new javax.swing.JButton();
        txtConsultarId = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaConsultarDNI = new javax.swing.JTable();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnBuscarDNI.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        btnBuscarDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarDNIActionPerformed(evt);
            }
        });

        txtConsultarId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultarIdActionPerformed(evt);
            }
        });

        TablaConsultarDNI.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "DNI", "NOMBRES", "APELLIDOS", "CARGO"
            }
        ));
        TablaConsultarDNI.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaConsultarDNIMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaConsultarDNI);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(12, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(txtConsultarId)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarDNI)))
                .addGap(10, 10, 10))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBuscarDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtConsultarId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtConsultarIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultarIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsultarIdActionPerformed

    private void btnBuscarDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarDNIActionPerformed
        String valor=txtConsultarId.getText();
        for (int i = 0; i < TablaConsultarDNI.getRowCount(); i++) {
             if (TablaConsultarDNI.getValueAt(i, 0).equals(valor)||TablaConsultarDNI.getValueAt(i, 1).equals(valor) ||TablaConsultarDNI.getValueAt(i, 2).equals(valor)||TablaConsultarDNI.getValueAt(i, 3).equals(valor) ) {
                TablaConsultarDNI.changeSelection(i, 0, false, false);
                txtDNI.setText(String.valueOf(TablaConsultarDNI.getValueAt(i, 0)));
                txtNombres.setText(String.valueOf(TablaConsultarDNI.getValueAt(i, 1)));
                txtApellidos.setText(String.valueOf(TablaConsultarDNI.getValueAt(i, 2)));
                txtCargo.setText(String.valueOf(TablaConsultarDNI.getValueAt(i, 3)));
        }                                            
        }
    }//GEN-LAST:event_btnBuscarDNIActionPerformed

    private void TablaConsultarDNIMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaConsultarDNIMouseClicked
       System.out.println("Ha presionado en un id de la tabla");
        int seleccionar = TablaConsultarDNI.rowAtPoint(evt.getPoint());
        txtDniGerente.setText(String.valueOf(TablaConsultarDNI.getValueAt(seleccionar, 0)));
        this.setVisible(false);
    }//GEN-LAST:event_TablaConsultarDNIMouseClicked
     
    private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"DNI","NOMBRE","APELLIDO","CARGO"};
        modelo=new DefaultTableModel(datos,columna);
        TablaConsultarDNI.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
}
    //Metodo para cargar DATOS
     private void CargarDatos(){
    Gerente gerent;
    try{
        for (int i = 0; i < RegistroGerentes.Listagerentes.size(); i++) {
            gerent=(Gerente)RegistroGerentes.Listagerentes.get(i);
            modelo.insertRow(cp, new Object[]{});
            modelo.setValueAt(gerent.getDNI(), cp, 0);
            modelo.setValueAt(gerent.getNombre(), cp, 1);
            modelo.setValueAt(gerent.getApellidos(), cp, 2);
            modelo.setValueAt(gerent.getAreaTrabajo(), cp, 3);
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consultar_DNIGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consultar_DNIGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consultar_DNIGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consultar_DNIGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consultar_DNIGerente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaConsultarDNI;
    private javax.swing.JButton btnBuscarDNI;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtConsultarId;
    // End of variables declaration//GEN-END:variables
}
