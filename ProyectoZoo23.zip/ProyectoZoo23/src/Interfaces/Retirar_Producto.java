
package Interfaces;
import Clases.Productos;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
//import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Retirar_Producto extends javax.swing.JFrame {
    
   // DefaultComboBoxModel modeloCombo=new DefaultComboBoxModel();
    //LINKEDLIST
   public static LinkedList<Productos> ListaProductos=new LinkedList<Productos>();
   //Variables Productos
   String idProducto,Nombre,Tipo,Cantidad;
   int cantidad=0;
    /**
     * Creates new form Retirar_Producto
     */
    public Retirar_Producto() {
        initComponents();
         this.setLocationRelativeTo(null);
        TablaProductos.addMouseListener(new MouseAdapter(){
            DefaultTableModel model= new DefaultTableModel();
            
            public void mouseClicked(MouseEvent e){
                int i=TablaProductos.getSelectedRow();
                idProducto=(TablaProductos.getValueAt(i, 0).toString());
                Nombre=(TablaProductos.getValueAt(i, 1).toString());
                Tipo=(TablaProductos.getValueAt(i, 2).toString());
                Cantidad=(TablaProductos.getValueAt(i, 3).toString());
              
            }
    });
         for (int i = 0; i < Registros_ProductosLimpieza.listPro.size(); i++) {
            ListaProductos.add(Registros_ProductosLimpieza.listPro.get(i));
        }
         
    }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtValorBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        CBTipo = new javax.swing.JComboBox<>();
        SpinnerCantidad = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaProductos = new javax.swing.JTable();
        btnRetirar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        fondo = new javax.swing.JLabel();

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/fondo1.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID_PRODUCTO:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("TIPO:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 40, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CANTIDAD:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, -1, -1));
        getContentPane().add(txtValorBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 150, 30));

        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 100, -1, -1));

        CBTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alimentos", "Medicina", "Implementos de Limpieza" }));
        CBTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBTipoActionPerformed(evt);
            }
        });
        getContentPane().add(CBTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, 120, 30));
        getContentPane().add(SpinnerCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 80, 30));

        TablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "IdProducto", "Nombre", "Tipo", "Cantidad"
            }
        ));
        TablaProductos.setRowHeight(30);
        jScrollPane1.setViewportView(TablaProductos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 470, 130));

        btnRetirar.setText("RETIRAR");
        btnRetirar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetirarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRetirar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 440, 90, 40));

        btnCancelar.setText("CANCELAR");
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 440, -1, 40));

        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/fondo1.png"))); // NOI18N
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void btnRetirarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetirarActionPerformed
    int confirmacion=JOptionPane.showConfirmDialog(null, "Esta seguro de retirar este producto", "CONFIRMACIÓN", JOptionPane.YES_NO_OPTION   ,JOptionPane.PLAIN_MESSAGE);
        if (confirmacion==JOptionPane.YES_OPTION) {
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (idProducto==ListaProductos.get(i).getIdProducto()) {
                    ListaProductos.remove(i);
                }
            }
        String matriz[][]=new String[ListaProductos.size()][4];
        for (int i = 0; i < ListaProductos.size(); i++) {
            matriz[i][0]=ListaProductos.get(i).getIdProducto();
             matriz[i][1]=ListaProductos.get(i).getNombre();
              matriz[i][2]=ListaProductos.get(i).getTipo();
               matriz[i][3]=ListaProductos.get(i).getStock();  
        }
         TablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "IdProducto", "Nombre", "Tipo", "Cantidad"
            }
        ){
            boolean[] canEdit = new boolean[]{
                false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        }else{
            JOptionPane.showMessageDialog(null, "No se retiro el producto");
        }
    }//GEN-LAST:event_btnRetirarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
     mostrarProductos(CBTipo.getSelectedIndex(), txtValorBuscar.getText());
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        Menu acceso=new Menu();
        acceso.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void CBTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBTipoActionPerformed
       
    }//GEN-LAST:event_CBTipoActionPerformed
   
    public void mostrar(){
        String matriz[][]=new String[ListaProductos.size()][4];
        for (int i = 0; i < ListaProductos.size(); i++) {
            matriz[i][0]=ListaProductos.get(i).getIdProducto();
             matriz[i][1]=ListaProductos.get(i).getNombre();
              matriz[i][2]=ListaProductos.get(i).getTipo();
               matriz[i][3]=ListaProductos.get(i).getStock();  
        }
         TablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "IdProducto", "Nombre", "Tipo", "Cantidad"
            }
        ){
            boolean[] canEdit = new boolean[]{
                false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
    }
    public void mostrarProductos(int filtro, String busqueda) {
        //Creacion de la tabla
        if (busqueda.equals("")) {
            busqueda = null;
        }
        String matriz[][] = new String[ListaProductos.size()][4];
        //Todos los registros
        //Alimentos
        if (filtro == 0 && busqueda == null) {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("alimento")) {
                    matriz[i][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }
        } else {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("alimento") && ListaProductos.get(i).getIdProducto().equalsIgnoreCase(busqueda)) {
                    matriz[g][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }
        }
        //Medicinas
        if (filtro == 1 && busqueda == null) {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("medicina")) {
                    matriz[g][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }
        } else {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("medicina") && ListaProductos.get(i).getIdProducto().equalsIgnoreCase(busqueda)) {
                    matriz[g][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }
        }
        //Limpieza
        if (filtro == 2 && busqueda == null) {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("limpieza")) {
                    matriz[g][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }

        } else {
            int g = 0;
            for (int i = 0; i < ListaProductos.size(); i++) {
                if (ListaProductos.get(i).getTipo().equalsIgnoreCase("limpieza") && ListaProductos.get(i).getIdProducto().equalsIgnoreCase(busqueda)) {
                    matriz[g][0] = ListaProductos.get(i).getIdProducto();
                    matriz[g][1] = ListaProductos.get(i).getNombre();          
                    matriz[g][2] = ListaProductos.get(i).getTipo();
                    matriz[g][3] = ListaProductos.get(i).getStock();
                    g++;
                }
            }
        }
         TablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "IdProducto", "Nombre", "Tipo", "Cantidad"
            }
        ){
            boolean[] canEdit = new boolean[]{
                false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Retirar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Retirar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Retirar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Retirar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Retirar_Producto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBTipo;
    private javax.swing.JLabel Fondo;
    private javax.swing.JSpinner SpinnerCantidad;
    private javax.swing.JTable TablaProductos;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnRetirar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtValorBuscar;
    // End of variables declaration//GEN-END:variables
}
