package Interfaces;

import Clases.Animal;
import Clases.DetalleDieta;
import Clases.Dieta;
import Clases.Productos;
import Ventanas.ConsultaIdAnimal;
import Ventanas.ConsultaIdProducto;
import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.JOptionPane;

public class RegistroDieta extends javax.swing.JFrame {
  SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    public static LinkedList<DetalleDieta> dieta = new LinkedList<DetalleDieta>();
 //   DetalleDieta opdieta =new Dieta();
    public int buscar;
DetalleDieta ddiet=null;
    public RegistroDieta() {
        initComponents();
        setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        txtCantidadPeso = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtConsultar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtIdAnimal = new javax.swing.JTextField();
        jButtonEliminar = new javax.swing.JButton();
        txtIdDieta = new javax.swing.JTextField();
        jButtonGuardar = new javax.swing.JButton();
        jButtonConsultar = new javax.swing.JButton();
        jButtonSalir = new javax.swing.JButton();
        jButtonActualizar = new javax.swing.JButton();
        BConsultarIdAnimal = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BConsultarIdProducto = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtIdProducto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        ComboBoxUnidadMedida = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        fechaAlimentacion = new com.toedter.calendar.JDateChooser();
        txtHora = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 0), 1, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCantidadPeso.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        txtCantidadPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadPesoActionPerformed(evt);
            }
        });
        jPanel1.add(txtCantidadPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 110, 20));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 51, 0));
        jLabel2.setText("REGISTRO DE DIETA");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, -1, -1));

        txtConsultar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPanel1.add(txtConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 180, 20));

        jLabel4.setForeground(new java.awt.Color(153, 102, 0));
        jLabel4.setText("ID ANIMAL");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, -1, -1));
        jPanel1.add(txtIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 230, 20));

        jButtonEliminar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonEliminar.setText("ELIMINAR");
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, 100, -1));

        txtIdDieta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdDietaActionPerformed(evt);
            }
        });
        jPanel1.add(txtIdDieta, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 230, -1));

        jButtonGuardar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonGuardar.setText("GUARDAR");
        jButtonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 430, -1, -1));

        jButtonConsultar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonConsultar.setText("CONSULTAR");
        jButtonConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsultarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConsultar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, 20));

        jButtonSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir.png"))); // NOI18N
        jButtonSalir.setBorder(null);
        jButtonSalir.setContentAreaFilled(false);
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, -1, 30));

        jButtonActualizar.setForeground(new java.awt.Color(153, 102, 0));
        jButtonActualizar.setText("ACTUALIZAR");
        jButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, -1, -1));

        BConsultarIdAnimal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdAnimal.setBorderPainted(false);
        BConsultarIdAnimal.setContentAreaFilled(false);
        BConsultarIdAnimal.setDefaultCapable(false);
        BConsultarIdAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdAnimalActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdAnimal, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, 30, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/006.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 70));

        jLabel6.setForeground(new java.awt.Color(153, 102, 0));
        jLabel6.setText("ID DIETA");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, -1, -1));

        BConsultarIdProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa (1).png"))); // NOI18N
        BConsultarIdProducto.setBorderPainted(false);
        BConsultarIdProducto.setContentAreaFilled(false);
        BConsultarIdProducto.setDefaultCapable(false);
        BConsultarIdProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BConsultarIdProductoActionPerformed(evt);
            }
        });
        jPanel1.add(BConsultarIdProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, 30, 30));

        jLabel7.setForeground(new java.awt.Color(153, 102, 0));
        jLabel7.setText("ID PRODUCTO");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, -1, -1));
        jPanel1.add(txtIdProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 230, -1));

        jLabel9.setForeground(new java.awt.Color(153, 102, 0));
        jLabel9.setText("HORA ALIMENTACION");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 350, -1, -1));

        ComboBoxUnidadMedida.setForeground(new java.awt.Color(102, 51, 0));
        ComboBoxUnidadMedida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "KILOGRAMOS", "LIBRAS" }));
        jPanel1.add(ComboBoxUnidadMedida, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 310, 100, -1));

        jLabel10.setForeground(new java.awt.Color(153, 102, 0));
        jLabel10.setText("CANTIDAD");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, -1, -1));

        jLabel11.setForeground(new java.awt.Color(153, 102, 0));
        jLabel11.setText("FECHA ALIMENTACION ");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, -1, -1));
        jPanel1.add(fechaAlimentacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 120, 20));

        txtHora.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jPanel1.add(txtHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, 90, 20));
        jPanel1.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 110, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed
       Menu remenu = new Menu();
        remenu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void jButtonConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsultarActionPerformed
   Integer Cant;
        String cant;
        try {
            String consultar = txtConsultar.getText().trim();
        boolean encontrar = false;
       
            for (int i = 0; i <dieta.size(); i++) {
                if (dieta.get(i).getIdDieta().equalsIgnoreCase(consultar)) {
                  ddiet=dieta.get(i);
                  encontrar=true;
                }
                 if (encontrar == true) {
                    txtIdDieta.setText(ddiet.getIdDieta());
                    txtIdAnimal.setText(ddiet.getIdAnimal());
                    txtIdProducto.setText(ddiet.getIdProducto());
                    txtCantidadPeso.setText(ddiet.getCantPeso());
                    txtHora.setText(ddiet.getHora());
                    txtFecha.setText(ddiet.getFecha());
//                    Date date= new SimpleDateFormat("dd/MM/yyyy").parse((String)toString());
//                    txtFecha.setText(date);
                    ComboBoxUnidadMedida.setSelectedItem(ddiet.getUMedida());
                    buscar = i;
                    JOptionPane.showMessageDialog(null, "Se ha encontrado la Dieta");
                }else{
                    JOptionPane.showMessageDialog(null, "No Se ha encontrado la Dieta"); 
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        ///limpiamos el campo
        txtConsultar.setText("");
    }//GEN-LAST:event_jButtonConsultarActionPerformed

    private void jButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarActionPerformed
        int res = JOptionPane.showConfirmDialog(RegistroDieta.this, "Esta seguro de Modificar los datos \nde esta Dieta", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                String idDieta = txtIdDieta.getText();
                String idAnimal = txtIdAnimal.getText();
                String idProducto = txtIdProducto.getText();
                String Cant = txtCantidadPeso.getText();
               String fechaAlim= formato.format(fechaAlimentacion.getDate());
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
                String h=txtHora.getText();
                DetalleDieta ddiet = new DetalleDieta(idDieta,idAnimal,Cant,idProducto,fechaAlim,Umed,h);
                RegistroDieta.dieta.set(buscar, ddiet);
                JOptionPane.showMessageDialog(null, "Dieta Modificada");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonActualizarActionPerformed

    private void jButtonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarActionPerformed
            System.out.println("Se ha presinado el Boton guardar");
        String CAnimal=txtIdAnimal.getText().trim();
        String CProducto= txtIdProducto.getText();
        boolean resp=false;
        boolean resp2=false;
        try {
            if (txtIdAnimal.getText().equals("") || txtIdDieta.getText().equals("") || txtIdProducto.getText().equals("") | txtCantidadPeso.getText().equals("") || txtCantidadPeso.getText().equals("") || txtHora.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "No ha rellenado todos los campos");
            } else {
                String idDieta = txtIdDieta.getText();
                String idAnimal=txtIdAnimal.getText();
                String idProducto=txtIdProducto.getText();
                String Cant = txtCantidadPeso.getText();
                String h = txtHora.getText();
                String fechaAlim = formato.format(fechaAlimentacion.getDate());
                String Umed = ComboBoxUnidadMedida.getSelectedItem().toString();
//
                for (int i = 0; i < Registros_ProductosLimpieza.listPro.size(); i++) {
                    Productos pro;
                    pro = (Productos) Registros_ProductosLimpieza.listPro.get(i);
                    if (CProducto.equalsIgnoreCase(pro.getIdProducto())) {
                        idProducto = CProducto;
                        resp=true;
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha encontrado el IdProducto");

                    }
                }
                
                for (int i = 0; i < RegistroAnimal.listaanimal.size(); i++) {
                    Animal ani;
                    ani = (Animal) RegistroAnimal.listaanimal.get(i);
                    if (CAnimal.equalsIgnoreCase(ani.getIdAnimal())) {
                        idAnimal = CAnimal;
                        resp2=true;
                        
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha encontrado el IdAnimal");
                    }
                }
                    if(resp=true){
                    if(resp2=true){
                    DetalleDieta ddieta = new DetalleDieta(idDieta, idAnimal, Cant, idProducto, Umed, fechaAlim, h);
                    dieta.add(ddieta);
                    System.out.println(dieta);
                    JOptionPane.showMessageDialog(null, "Se ha guardado correctamente");
                    }else{
                     JOptionPane.showMessageDialog(null, "NO SE HA PODIDO REGISTRAR LA DIETA \nNO EXISTE EL ID DEL ANIMAL INGRESADO"); 
                    }
                    }else{
                     JOptionPane.showMessageDialog(null, "NO SE HA PODIDO REGISTRAR LA DIETA \nNO EXISTE EL ID DEL PRODUCTO INGRESADO"); 
                    }
                
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        LimpiarDatos();
    }//GEN-LAST:event_jButtonGuardarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
        int res = JOptionPane.showConfirmDialog(RegistroDieta.this, "Esta seguro de eliminar esta Dieta", "confirmacion", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            try {
                RegistroDieta.dieta.remove(buscar);
//                txtIdDieta.setText("");
//                txtIdAnimal.setText("");
//                txtCantidadPeso.setText("");
//                txtIdProducto.setText(""); 
//                txtHora.setText("");
//                ComboBoxUnidadMedida.setSelectedItem("Seleccione");
                   LimpiarDatos();

                JOptionPane.showMessageDialog(null, "Dieta Eliminada");
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void txtIdDietaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdDietaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdDietaActionPerformed

    private void BConsultarIdAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdAnimalActionPerformed
                System.out.println("Ha presionado buscar id animal");
                ConsultaIdAnimal verveid=new ConsultaIdAnimal();
                verveid.setVisible(true);
    }//GEN-LAST:event_BConsultarIdAnimalActionPerformed

    private void BConsultarIdProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BConsultarIdProductoActionPerformed
         System.out.println("Ha presionado buscar id producto");
                ConsultaIdProducto verveidP=new ConsultaIdProducto();
                verveidP.setVisible(true);
    }//GEN-LAST:event_BConsultarIdProductoActionPerformed

    private void txtCantidadPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadPesoActionPerformed

    public void LimpiarDatos() {
        //limpiar datos
        txtIdDieta.setText("");
        txtIdAnimal.setText("");
        txtCantidadPeso.setText("");
         txtIdProducto.setText("");
         txtHora.setText("");
         fechaAlimentacion.setCalendar(null);
        ComboBoxUnidadMedida.setSelectedItem("Seleccione");

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroDieta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroDieta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BConsultarIdAnimal;
    private javax.swing.JButton BConsultarIdProducto;
    private javax.swing.JComboBox<String> ComboBoxUnidadMedida;
    private com.toedter.calendar.JDateChooser fechaAlimentacion;
    private javax.swing.JButton jButtonActualizar;
    private javax.swing.JButton jButtonConsultar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonGuardar;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JTextField txtCantidadPeso;
    public static javax.swing.JTextField txtConsultar;
    private javax.swing.JTextField txtFecha;
    public static javax.swing.JTextField txtHora;
    public static javax.swing.JTextField txtIdAnimal;
    public static javax.swing.JTextField txtIdDieta;
    public static javax.swing.JTextField txtIdProducto;
    // End of variables declaration//GEN-END:variables
}
