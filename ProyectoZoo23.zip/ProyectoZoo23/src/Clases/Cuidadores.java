package Clases;

public class Cuidadores extends Personal {

    private String especificacion;

    public Cuidadores() {
        super();
    }

    public Cuidadores(String especificacion) {
        this.especificacion = especificacion;
    }

    public Cuidadores(String especificacion, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo);
        this.especificacion = especificacion;
    }

    public Cuidadores(String especificacion, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo, String Id_TipoUsuario, String TipoUsuario, String Usuario, String Contraseña) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo, Id_TipoUsuario, TipoUsuario, Usuario, Contraseña);
        this.especificacion = especificacion;
    }

    public String getEspecificacion() {
        return especificacion;
    }

    //Getter and setter
    public void setEspecificacion(String especificacion) {
        this.especificacion = especificacion;
    }

    @Override
    public String toString() {
        return super.toString() + "especificacion=" + especificacion + '}';
    }

}
