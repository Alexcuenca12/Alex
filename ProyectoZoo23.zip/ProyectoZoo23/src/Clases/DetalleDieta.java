/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author The Prince
 */
public class DetalleDieta extends Dieta{
     private String cantidad; 
     private String idProducto;
     private String Umedida;
     private String fechaInicio;
     private String FechaFin;
     private String hora;
     private String estadoAlimentacion;

    public DetalleDieta() {
        super();
    }

    public DetalleDieta(String cantidad, String idProducto, String Umedida, String fechaInicio, String FechaFin, String hora, String estadoAlimentacion) {
        this.cantidad = cantidad;
        this.idProducto = idProducto;
        this.Umedida = Umedida;
        this.fechaInicio = fechaInicio;
        this.FechaFin = FechaFin;
        this.hora = hora;
        this.estadoAlimentacion = estadoAlimentacion;
    }

    public DetalleDieta(String cantidad, String idProducto, String Umedida, String fechaInicio, String FechaFin, String hora, String estadoAlimentacion, String idDieta, String idAnimal) {
        super(idDieta, idAnimal);
        this.cantidad = cantidad;
        this.idProducto = idProducto;
        this.Umedida = Umedida;
        this.fechaInicio = fechaInicio;
        this.FechaFin = FechaFin;
        this.hora = hora;
        this.estadoAlimentacion = estadoAlimentacion;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getUmedida() {
        return Umedida;
    }

    public void setUmedida(String Umedida) {
        this.Umedida = Umedida;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String FechaFin) {
        this.FechaFin = FechaFin;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEstadoAlimentacion() {
        return estadoAlimentacion;
    }

    public void setEstadoAlimentacion(String estadoAlimentacion) {
        this.estadoAlimentacion = estadoAlimentacion;
    }

    @Override
    public String toString() {
        return "DetalleDieta{" + "cantidad=" + cantidad + ", idProducto=" + idProducto + ", Umedida=" + Umedida + ", fechaInicio=" + fechaInicio + ", FechaFin=" + FechaFin + ", hora=" + hora + ", estadoAlimentacion=" + estadoAlimentacion + '}';
    }

 
}