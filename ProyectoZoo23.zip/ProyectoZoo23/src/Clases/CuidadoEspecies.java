/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public class CuidadoEspecies {
    private String DniCuidador;
    private String TipoEspecie;
    private String fechaEmision;

    public CuidadoEspecies() {
    }

    public CuidadoEspecies(String DniCuidador, String TipoEspecie, String fechaEmision) {
        this.DniCuidador = DniCuidador;
        this.TipoEspecie = TipoEspecie;
        this.fechaEmision = fechaEmision;
    }

    public String getDniCuidador() {
        return DniCuidador;
    }

    public void setDniCuidador(String DniCuidador) {
        this.DniCuidador = DniCuidador;
    }

    public String getTipoEspecie() {
        return TipoEspecie;
    }

    public void setTipoEspecie(String TipoEspecie) {
        this.TipoEspecie = TipoEspecie;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    @Override
    public String toString() {
        return "CuidadoEspecies{" + "DniCuidador=" + DniCuidador + ", TipoEspecie=" + TipoEspecie + ", fechaEmision=" + fechaEmision + '}';
    }

  
}
