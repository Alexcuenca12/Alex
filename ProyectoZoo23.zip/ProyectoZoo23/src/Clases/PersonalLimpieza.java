/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public class PersonalLimpieza extends Personal{
    private int diasLabor;

    public PersonalLimpieza() {
        super();
    }

    public PersonalLimpieza(int diasLabor) {
        this.diasLabor = diasLabor;
    }

    public PersonalLimpieza(int diasLabor, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo);
        this.diasLabor = diasLabor;
    }

    public PersonalLimpieza(int diasLabor, String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String cargo, String areaTrabajo, String Id_TipoUsuario, String TipoUsuario, String Usuario, String Contraseña) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo, Id_TipoUsuario, TipoUsuario, Usuario, Contraseña);
        this.diasLabor = diasLabor;
    }

    public int getDiasLabor() {
        return diasLabor;
    }

    public void setDiasLabor(int diasLabor) {
        this.diasLabor = diasLabor;
    }

  

    @Override
    public String toString() {
        return super.toString()+"diasLabor=" + diasLabor;
    }
    
    
}
