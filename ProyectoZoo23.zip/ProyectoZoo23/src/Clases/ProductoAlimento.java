
package Clases;


public class ProductoAlimento extends Productos {
    private String valorNutricional;

    public ProductoAlimento() {
        super();
    }

    public ProductoAlimento(String valorNutricional) {
        this.valorNutricional = valorNutricional;
    }

    public ProductoAlimento(String valorNutricional, String idProducto, String nombre, String descripcion, double precio, String fechaCaducacion, String tipo, String stock, String NifProveedor) {
        super(idProducto, nombre, descripcion, precio, fechaCaducacion, tipo, stock, NifProveedor);
        this.valorNutricional = valorNutricional;
    }

    public String getValorNutricional() {
        return valorNutricional;
    }

    public void setValorNutricional(String valorNutricional) {
        this.valorNutricional = valorNutricional;
    }

    @Override
    public String toString() {
        return super.toString()+"ProductoAlimento{" + "valorNutricional=" + valorNutricional;
    }
    
}
