
package Clases;

public class ProductoMedicina extends Productos {
    private String viaAdministracion;
    private String composicionComprimido;

    public ProductoMedicina() {
        super();
    }

    public ProductoMedicina(String viaAdministracion, String composicionComprimido) {
        this.viaAdministracion = viaAdministracion;
        this.composicionComprimido = composicionComprimido;
    }

    public ProductoMedicina(String viaAdministracion, String composicionComprimido, String idProducto, String nombre, String descripcion, double precio, String fechaCaducacion, String tipo, String stock, String NifProveedor) {
        super(idProducto, nombre, descripcion, precio, fechaCaducacion, tipo, stock, NifProveedor);
        this.viaAdministracion = viaAdministracion;
        this.composicionComprimido = composicionComprimido;
    }

    public String getViaAdministracion() {
        return viaAdministracion;
    }

    public void setViaAdministracion(String viaAdministracion) {
        this.viaAdministracion = viaAdministracion;
    }

    public String getComposicionComprimido() {
        return composicionComprimido;
    }

    public void setComposicionComprimido(String composicionComprimido) {
        this.composicionComprimido = composicionComprimido;
    }

    @Override
    public String toString() {
        return super.toString()+ "viaAdministracion=" + viaAdministracion + ", composicionComprimido=" + composicionComprimido + '}';
    }
    
}
