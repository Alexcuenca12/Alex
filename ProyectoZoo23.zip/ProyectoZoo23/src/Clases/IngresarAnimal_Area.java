
package Clases;

public class IngresarAnimal_Area {
    private String idAnimal;
    
    private String idArea;

    private String estado;
    

    public IngresarAnimal_Area() {
    }

    public IngresarAnimal_Area(String idAnimal, String idArea, String estado) {
        this.idAnimal = idAnimal;
        this.idArea = idArea;
        this.estado = estado;
    }

    public String getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(String idAnimal) {
        this.idAnimal = idAnimal;
    }

    public String getIdArea() {
        return idArea;
    }

    public void setIdArea(String idArea) {
        this.idArea = idArea;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "IngresarAnimal_Area{" + "idAnimal=" + idAnimal + ", idArea=" + idArea + ", estado=" + estado + '}';
    }
    
    
    
}
