
package Clases;

public class Proveedor {
    private String NifProveedor;
    private String Nombre;
    private String apellido;
    private String telefono;
    private String correo;
    private String nombreEmpresa;
}
