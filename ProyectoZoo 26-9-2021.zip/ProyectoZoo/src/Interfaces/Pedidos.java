
package Interfaces;
import Clases.Pedido;
import java.util.LinkedList;
public class Pedidos extends javax.swing.JFrame {

    /**
     * Creates new form Pedidos
     */
    public Pedidos() {
        initComponents();
    }

    //LinkedList
    public static LinkedList<Pedido> listapedidos=new LinkedList<Pedido>();
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnRealizar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        txtIdproveedor = new javax.swing.JTextField();
        txtNombreproducto = new javax.swing.JTextField();
        SpinnerCantidad = new javax.swing.JSpinner();
        CBTipoAlimento = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tablapedidos = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID PROVEEDOR:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NOMBRE PRODUCTO:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CANTIDAD:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, -1, -1));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TIPO:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, -1));

        btnRealizar.setText("REALIZAR");
        btnRealizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRealizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRealizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, -1, -1));

        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, -1, -1));
        getContentPane().add(txtIdproveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 130, 30));
        getContentPane().add(txtNombreproducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 130, 30));
        getContentPane().add(SpinnerCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 60, 30));

        CBTipoAlimento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alimentos", "Medicinas", "Implementos de limpieza" }));
        getContentPane().add(CBTipoAlimento, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 170, 30));

        Tablapedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id Proveedor", "Nombre Producto", "Cantidad", "Tipo Producto"
            }
        ));
        Tablapedidos.setRowHeight(30);
        jScrollPane1.setViewportView(Tablapedidos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 100, 370, 140));

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TABLA DE PEDIDOS");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 70, -1, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/fondo1.png"))); // NOI18N
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 722, 417));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRealizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRealizarActionPerformed
        
        String idProveedor= txtIdproveedor.getText();
        String NombreProducto= txtNombreproducto.getText();
        int Cantidad= Integer.parseInt(SpinnerCantidad.getValue().toString());
        String Tipo=CBTipoAlimento.getSelectedItem().toString();
        
        Pedido mipedido=new Pedido(idProveedor, NombreProducto, Cantidad, Tipo);
        txtIdproveedor.setText("");
        txtNombreproducto.setText("");
        CBTipoAlimento.setSelectedItem("Alimentos");
        listapedidos.add(mipedido);
        mostrar();
        
    }//GEN-LAST:event_btnRealizarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        txtIdproveedor.setText("");
        txtNombreproducto.setText("");
        CBTipoAlimento.setSelectedItem("Alimentos");
       
    }//GEN-LAST:event_btnCancelarActionPerformed
    
    public void mostrar(){
        String matriz[][]=new String[listapedidos.size()][4];
        for (int i = 0; i <listapedidos.size(); i++) {
            matriz[i][0]=listapedidos.get(i).getId_proveedor();
            matriz[i][1]=listapedidos.get(i).getNombre_producto();
            matriz[i][2]=""+listapedidos.get(i).getCantidad();
            matriz[i][3]=listapedidos.get(i).getTipo();  
        }
         Tablapedidos.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "Id Proveedor", "Nombre Producto", "Cantidad", "Tipo Producto"
            }
        )
           {
            boolean[] canEdit = new boolean[]{
                false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }      
           });
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pedidos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBTipoAlimento;
    private javax.swing.JSpinner SpinnerCantidad;
    private javax.swing.JTable Tablapedidos;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnRealizar;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtIdproveedor;
    private javax.swing.JTextField txtNombreproducto;
    // End of variables declaration//GEN-END:variables
}
