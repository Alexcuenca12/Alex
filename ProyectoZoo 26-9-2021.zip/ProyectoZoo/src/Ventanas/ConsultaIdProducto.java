
package Ventanas;

import Clases.Productos;
import Interfaces.Registros_Productos;
import static Interfaces.Registros_Productos.txtPrecio;
import static Interfaces.Registros_Productos.txtStock;
import static Interfaces.Registros_Productos.txt_idProducto;
import static Interfaces.Registros_Productos.txt_nombre;
import javax.swing.table.DefaultTableModel;
import static Interfaces.RegistroDieta.txtCantidadPeso;


public class ConsultaIdProducto extends javax.swing.JFrame {
   private DefaultTableModel modelo;
    int cp = 0;
    public ConsultaIdProducto() {
        initComponents();
        this.setLocationRelativeTo(null);
       CargarModelo();
      CargarDatos();
    }
   private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"ID PRODUCOT","NOMBRE","PRECIO","STOCK"};
        modelo=new DefaultTableModel(datos,columna);
        TableConsultaidProducto.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
}
private void CargarDatos(){
    Productos prod;
    try{
        for (int i = 0; i < Registros_Productos.listPro.size(); i++) {
            prod=(Productos)Registros_Productos.listPro.get(i);
            modelo.insertRow(cp, new Object[]{});
            modelo.setValueAt(prod.getIdProducto(), cp, 0);
            modelo.setValueAt(prod.getNombre(), cp, 1);
            modelo.setValueAt(prod.getPrecio(), cp, 2);
           modelo.setValueAt(prod.getStock(), cp, 3);
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane8 = new javax.swing.JScrollPane();
        TableConsultaidProducto = new javax.swing.JTable();
        txtConsultaridProducto = new javax.swing.JTextField();
        ButtonBuscarProd = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableConsultaidProducto.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        TableConsultaidProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "PRECIO", "STOCK"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableConsultaidProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableConsultaidProductoMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(TableConsultaidProducto);

        getContentPane().add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 230, 120));
        getContentPane().add(txtConsultaridProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, -1));

        ButtonBuscarProd.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        ButtonBuscarProd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lupa (1).png"))); // NOI18N
        ButtonBuscarProd.setBorderPainted(false);
        ButtonBuscarProd.setContentAreaFilled(false);
        ButtonBuscarProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBuscarProdActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonBuscarProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 60, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TableConsultaidProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableConsultaidProductoMouseClicked
        System.out.println("Ha presionado en un id de la tabla");
        int seleccionar = TableConsultaidProducto.rowAtPoint(evt.getPoint());
        txtCantidadPeso.setText(String.valueOf(TableConsultaidProducto.getValueAt(seleccionar, 0)));

        this.setVisible(false);


    }//GEN-LAST:event_TableConsultaidProductoMouseClicked

    private void ButtonBuscarProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBuscarProdActionPerformed
    String valor = txtConsultaridProducto.getText();
   for (int i = 0; i < TableConsultaidProducto.getRowCount(); i++) {
            if (TableConsultaidProducto.getValueAt(i, 0).equals(valor)||TableConsultaidProducto.getValueAt(i, 1).equals(valor) ||TableConsultaidProducto.getValueAt(i, 2).equals(valor)||TableConsultaidProducto.getValueAt(i, 3).equals(valor) ) {
                TableConsultaidProducto.changeSelection(i, 0, false, false);
                txt_idProducto.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 0)));
                txt_nombre.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 1)));
                txtPrecio.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 2)));
                txtStock.setText(String.valueOf(TableConsultaidProducto.getValueAt(i, 3)));


    }                                            
   }    
    }//GEN-LAST:event_ButtonBuscarProdActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaIdProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBuscarProd;
    public static javax.swing.JTable TableConsultaidProducto;
    private javax.swing.JScrollPane jScrollPane8;
    public static javax.swing.JTextField txtConsultaridProducto;
    // End of variables declaration//GEN-END:variables
}
