
package Ventanas;

import Clases.Animal;
import Interfaces.RegistroAnimal;
import static Interfaces.RegistroAnimal.nombrecien;
import static Interfaces.RegistroAnimal.nombrevulg;
import static Interfaces.RegistroDieta.txtIdAnimal;
import javax.swing.table.DefaultTableModel;
import static Interfaces.RegistroAnimal.idespecie;

public class ConsultaIdAnimal extends javax.swing.JFrame {
    private DefaultTableModel modelo;
    int c = 0;

    public ConsultaIdAnimal() {
        initComponents();
        this.setLocationRelativeTo(null);
        CargarModelo();
        CargarDatos();
    }

 private void CargarModelo(){ //establecemos un modelo de tabla
    try{
        String datos[][]={};
        String columna[]={"ID ANIMAL","NOMBRE CIENTIFICO","NOMBRE VULGAR"};
        modelo=new DefaultTableModel(datos,columna);
        TableConsultaAnimal.setModel(modelo);
    }catch(Exception e){
        System.out.println(e);
    }
}
private void CargarDatos(){
    Animal aanimal;
    try{
        for (int i = 0; i < RegistroAnimal.listaanimal.size(); i++) {
            aanimal=(Animal)RegistroAnimal.listaanimal.get(i);
            modelo.insertRow(c, new Object[]{});
            modelo.setValueAt(aanimal.getIdAnimal(), c, 0);
            modelo.setValueAt(aanimal.getNombre_cienti(), c, 1);
            modelo.setValueAt(aanimal.getNombre_vulga(), c, 2);
        }
    }catch(Exception ex){
        System.out.println(ex);
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane8 = new javax.swing.JScrollPane();
        TableConsultaAnimal = new javax.swing.JTable();
        txtConsultaridAnimla = new javax.swing.JTextField();
        ButtonBuscar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableConsultaAnimal.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        TableConsultaAnimal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID AULA", "NOMBRE", "CAPACIDAD"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableConsultaAnimal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableConsultaAnimalMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(TableConsultaAnimal);

        getContentPane().add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 230, 120));
        getContentPane().add(txtConsultaridAnimla, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, -1));

        ButtonBuscar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        ButtonBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lupa (1).png"))); // NOI18N
        ButtonBuscar.setBorderPainted(false);
        ButtonBuscar.setContentAreaFilled(false);
        ButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 60, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TableConsultaAnimalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableConsultaAnimalMouseClicked
          System.out.println("Ha presionado en un id de la tabla");
         int seleccionar=TableConsultaAnimal.rowAtPoint(evt.getPoint());
         txtIdAnimal.setText(String.valueOf(TableConsultaAnimal.getValueAt(seleccionar,0)));
          this.setVisible(false);
    }//GEN-LAST:event_TableConsultaAnimalMouseClicked

    private void ButtonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBuscarActionPerformed
String valor = txtConsultaridAnimla.getText();
   for (int i = 0; i < TableConsultaAnimal.getRowCount(); i++) {
            if (TableConsultaAnimal.getValueAt(i, 0).equals(valor)||TableConsultaAnimal.getValueAt(i, 1).equals(valor) ||TableConsultaAnimal.getValueAt(i, 2).equals(valor) ) {
                TableConsultaAnimal.changeSelection(i, 0, false, false);
                idespecie.setText(String.valueOf(TableConsultaAnimal.getValueAt(i, 0)));
                nombrecien.setText(String.valueOf(TableConsultaAnimal.getValueAt(i, 1)));
                nombrevulg.setText(String.valueOf(TableConsultaAnimal.getValueAt(i, 2)));

    }//GEN-LAST:event_ButtonBuscarActionPerformed
   }
   }  
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaIdAnimal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaIdAnimal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBuscar;
    public static javax.swing.JTable TableConsultaAnimal;
    private javax.swing.JScrollPane jScrollPane8;
    public static javax.swing.JTextField txtConsultaridAnimla;
    // End of variables declaration//GEN-END:variables
}
