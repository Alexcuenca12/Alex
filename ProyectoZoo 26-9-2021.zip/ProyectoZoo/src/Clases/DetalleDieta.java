/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author The Prince
 */
public class DetalleDieta extends Dieta{
     private String cantPeso; 
     private String idProducto; //sec onceta con producto

    public DetalleDieta() {
        super();
    }

    public DetalleDieta(String cantPeso, String idProducto) {
        this.cantPeso = cantPeso;
        this.idProducto = idProducto;
    }

    public DetalleDieta(String cantPeso, String idProducto, String idDieta, String idAnimal) {
        super(idDieta, idAnimal);
        this.cantPeso = cantPeso;
        this.idProducto = idProducto;
    }

    public String getCantPeso() {
        return cantPeso;
    }

    public void setCantPeso(String cantPeso) {
        this.cantPeso = cantPeso;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    @Override
    public String toString() {
        return "DetalleDieta{" + "cantPeso=" + cantPeso + ", idProducto=" + idProducto + '}';
    }

}