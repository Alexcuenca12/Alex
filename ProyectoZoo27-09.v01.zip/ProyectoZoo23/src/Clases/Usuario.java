
package Clases;

import java.util.Vector;
import Clases.Capa;

public class Usuario {
    //Atributos
    private String Id_TipoUsuario;
    private String TipoUsuario;
    private String Usuario;
    private String Contraseña;
    
    //Constructores

    public Usuario() {
    }

    public Usuario(String Id_TipoUsuario, String TipoUsuario, String Usuario, String Contraseña) {
        this.Id_TipoUsuario = Id_TipoUsuario;
        this.TipoUsuario = TipoUsuario;
        this.Usuario = Usuario;
        this.Contraseña = Contraseña;
    }
    
   
    //Setter and Getters

    public String getId_TipoUsuario() {
        return Id_TipoUsuario;
    }

    public void setId_TipoUsuario(String Id_TipoUsuario) {
        this.Id_TipoUsuario = Id_TipoUsuario;
    }

    public String getTipoUsuario() {
        return TipoUsuario;
    }

    public void setTipoUsuario(String TipoUsuario) {
        this.TipoUsuario = TipoUsuario;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }
    //Metodo para que los usuarios no se puedan repetir
    public static int verificarUsuario(String usuario){
        Vector listaUsaurios=mostrar();
        Usuario obj; //Creamos un objeto de la clase usuario
        for (int i = 0; i < listaUsaurios.size(); i++) {
            obj=(Usuario)listaUsaurios.elementAt(i); //Almacena los datos que se van agregar
            if (obj.getUsuario().equalsIgnoreCase(usuario)) { // 
                return i; //Si encuentra el mismo usuario
            }
        }
        return -1; //Si esque no encuentra el mismo Usuario
    }
    public static int verificarContraseña(String contraseña){
        Vector listaUsaurios=mostrar();
        Usuario obj; //Creamos un objeto de la clase usuario
        for (int i = 0; i < listaUsaurios.size(); i++) {
            obj=(Usuario)listaUsaurios.elementAt(i); //Almacena los datos que se van agregar
            if (obj.getUsuario().equalsIgnoreCase(contraseña)) { // 
                return i; //Si encuentra la misma contraseña
            }
        }
        return -1; //Si esque no encuentra la misma contraseña
    }
    
    //Llamar al vector
    public static Vector mostrar(){
        return Capa.mostrar();
    }
    
    //Metodo Verificar logeo
    public static int verificarLogeo(String usuario, String contraseña, String tipoUser){
        Vector listaUsaurios=mostrar();
        Usuario obj; //Creamos un objeto de la clase usuario
        for (int i = 0; i < listaUsaurios.size(); i++) {
            obj=(Usuario)listaUsaurios.elementAt(i);
            if (obj.getUsuario().equalsIgnoreCase(usuario) && obj.getContraseña().equalsIgnoreCase(contraseña)
                    && obj.getTipoUsuario().equalsIgnoreCase(tipoUser)) {
                return i;
            }
        } 
        return -1;
    }
    
    //Metodo cambio de contraseña
    public static int Recuperarcontraseña(String usuario, String newcontraseña){
    Vector listaUsaurios=mostrar();
        Usuario obj; //Creamos un objeto de la clase usuario
        for (int i = 0; i < listaUsaurios.size(); i++) {
            obj=(Usuario)listaUsaurios.elementAt(i);
            if (obj.getUsuario().equalsIgnoreCase(usuario)&&obj.getContraseña().equalsIgnoreCase(newcontraseña)) {
                return i;
            }
    }
        return -1;
    }
    

    @Override
    public String toString() {
        return "Usuario{" + "Id_TipoUsuario=" + Id_TipoUsuario + ", TipoUsuario=" + TipoUsuario + ", Usuario=" + Usuario + ", Contrase\u00f1a=" + Contraseña + '}';
    }

   
    
}
