/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public class Veterinario extends Personal{
    private String  especialidad;

    public Veterinario() {
        super();
    }

    public Veterinario(String especialidad) {
        this.especialidad = especialidad;
    }

    public Veterinario(String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion,String especialidad,String cargo, String areaTrabajo) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion, cargo, areaTrabajo);
        this.especialidad = especialidad;
    }

    public Veterinario(String DNI, String Nombre, String Apellidos, int edad, String genero, String direccion, String especialidad, String cargo, String areaTrabajo, String Id_TipoUsuario, String Usuario, String Contraseña) {
        super(DNI, Nombre, Apellidos, edad, genero, direccion,especialidad, cargo, areaTrabajo, Id_TipoUsuario, Usuario, Contraseña);
        this.especialidad = especialidad;
    }


    //Getter and Setter

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

 
    @Override
    public String toString() {
        return super.toString()+ ", especialidad=" + especialidad ;
    }
   
    
    
}
