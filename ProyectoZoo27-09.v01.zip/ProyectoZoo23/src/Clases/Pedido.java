/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


public class Pedido {
    private String Id_proveedor;
    private String Nombre_producto;
    private int cantidad;
    private String tipo;
    
    //Constructor
    public Pedido() {
    }
    //Constructor full
    public Pedido(String Id_proveedor, String Nombre_producto, int cantidad, String tipo) {
        this.Id_proveedor = Id_proveedor;
        this.Nombre_producto = Nombre_producto;
        this.cantidad = cantidad;
        this.tipo = tipo;
    }
    
    //Getter and Setter
    public String getId_proveedor() {
        return Id_proveedor;
    }

    public void setId_proveedor(String Id_proveedor) {
        this.Id_proveedor = Id_proveedor;
    }

    public String getNombre_producto() {
        return Nombre_producto;
    }

    public void setNombre_producto(String Nombre_producto) {
        this.Nombre_producto = Nombre_producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    //Metodos ToString
    @Override
    public String toString() {
        return "Pedido{" + "Id_proveedor=" + Id_proveedor + ", Nombre_producto=" + Nombre_producto + ", cantidad=" + cantidad + ", tipo=" + tipo + '}';
    }
    
}
